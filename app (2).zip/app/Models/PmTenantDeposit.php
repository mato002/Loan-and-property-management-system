<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PmTenantDeposit extends Model
{
    protected $table = 'pm_tenant_deposits';

    protected $fillable = [
        'tenant_id',
        'amount',
        'status',
        'agent_user_id',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
        ];
    }
}

