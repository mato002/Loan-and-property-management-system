<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmLandlordPayout extends Model
{
    protected $table = 'pm_landlord_payouts';

    protected $fillable = [
        'agent_user_id',
        'total_amount',
        'status',
        'created_by',
        'approved_by',
        'paid_at',
    ];

    protected function casts(): array
    {
        return [
            'total_amount' => 'decimal:2',
            'paid_at' => 'datetime',
        ];
    }

    public function items(): HasMany
    {
        return $this->hasMany(PmLandlordPayoutItem::class, 'payout_id');
    }
}

