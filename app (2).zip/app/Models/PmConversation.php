<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PmConversation extends Model
{
    protected $table = 'pm_conversations';

    protected $fillable = [
        'topic',
        'category',
        'status',
        'priority',
        'pm_tenant_id',
        'property_id',
        'assigned_to_user_id',
        'last_message_at',
    ];

    protected function casts(): array
    {
        return [
            'last_message_at' => 'datetime',
        ];
    }

    public function messages(): HasMany
    {
        return $this->hasMany(PmConversationMessage::class, 'conversation_id');
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(PmTenant::class, 'pm_tenant_id');
    }
}
