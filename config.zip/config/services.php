<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'property_webhooks' => [
        'secret' => env('PROPERTY_WEBHOOK_SECRET'),
    ],

    'property_banks' => [
        'timeout_seconds' => (int) env('PROPERTY_BANK_TIMEOUT', 20),
        'providers' => [
            'kcb' => [
                'base_url' => env('PROPERTY_BANK_KCB_BASE_URL'),
                'api_key' => env('PROPERTY_BANK_KCB_API_KEY'),
                'api_secret' => env('PROPERTY_BANK_KCB_API_SECRET'),
                'merchant_code' => env('PROPERTY_BANK_KCB_MERCHANT_CODE'),
                'webhook_secret' => env('PROPERTY_BANK_KCB_WEBHOOK_SECRET'),
            ],
            'equity' => [
                'base_url' => env('PROPERTY_BANK_EQUITY_BASE_URL'),
                'api_key' => env('PROPERTY_BANK_EQUITY_API_KEY'),
                'api_secret' => env('PROPERTY_BANK_EQUITY_API_SECRET'),
                'merchant_code' => env('PROPERTY_BANK_EQUITY_MERCHANT_CODE'),
                'webhook_secret' => env('PROPERTY_BANK_EQUITY_WEBHOOK_SECRET'),
            ],
            'coop' => [
                'base_url' => env('PROPERTY_BANK_COOP_BASE_URL'),
                'api_key' => env('PROPERTY_BANK_COOP_API_KEY'),
                'api_secret' => env('PROPERTY_BANK_COOP_API_SECRET'),
                'merchant_code' => env('PROPERTY_BANK_COOP_MERCHANT_CODE'),
                'webhook_secret' => env('PROPERTY_BANK_COOP_WEBHOOK_SECRET'),
            ],
        ],
    ],

];
