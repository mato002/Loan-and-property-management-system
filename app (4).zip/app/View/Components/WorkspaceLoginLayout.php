<?php

namespace App\View\Components;

use Illuminate\View\Component;
use Illuminate\View\View;

class WorkspaceLoginLayout extends Component
{
    public function __construct(
        public ?string $title = null,
    ) {}

    public function render(): View
    {
        return view('layouts.guest-workspace-login', [
            'title' => $this->title ?? config('app.name'),
        ]);
    }
}
