<x-property-layout>
    <x-slot name="header">Dashboard</x-slot>

    <x-property.page
        title="Dashboard"
        subtitle="Portfolio snapshot — counts, cash movement, maintenance intake, and year-to-date billing vs collections ({{ $chartYear }})."
    >
        @include('property.agent.partials.dashboard_stats_inner')
    </x-property.page>
</x-property-layout>
