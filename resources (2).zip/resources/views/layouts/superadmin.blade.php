@php
    $companyName = config('app.name', 'Application');
    $displayName = strtolower($companyName) === 'laravel' ? 'Property Management System' : $companyName;
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ $title ?? ('Super Admin — '.$displayName) }}</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700&display=swap" rel="stylesheet" />
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <style>
            @media (min-width: 1024px) {
                .superadmin-sidebar[data-collapsed="1"] .sa-collapse-text { display: none !important; }
                .superadmin-sidebar[data-collapsed="1"] .sa-collapse-center { justify-content: center !important; }
            }
        </style>
    </head>
    <body class="h-screen min-h-0 overflow-hidden bg-[#e8ecf1] text-slate-900 antialiased" style="font-family: 'Plus Jakarta Sans', ui-sans-serif, system-ui, sans-serif;">
        <x-swal-flash />

        <div
            class="h-full min-h-0 flex overflow-hidden"
            x-data="{
                saSidebarOpen: false,
                saProfileOpen: false,
                saSidebarDesktopOpen: true,
                init() {
                    const saved = window.localStorage.getItem('superadmin.sidebar.desktop.open');
                    if (saved !== null) {
                        this.saSidebarDesktopOpen = saved === '1';
                    }
                },
                toggleSaDesktopSidebar() {
                    this.saSidebarDesktopOpen = !this.saSidebarDesktopOpen;
                    window.localStorage.setItem('superadmin.sidebar.desktop.open', this.saSidebarDesktopOpen ? '1' : '0');
                }
            }"
        >
            {{-- Mobile sidebar overlay --}}
            <div
                x-show="saSidebarOpen"
                x-cloak
                class="fixed inset-0 z-40 bg-slate-900/50 lg:hidden"
                @click="saSidebarOpen = false"
            ></div>

            {{-- Mobile sidebar drawer --}}
            <aside
                x-show="saSidebarOpen"
                x-cloak
                class="fixed inset-y-0 left-0 z-50 w-72 lg:hidden flex flex-col border-r border-slate-200 bg-white shadow-xl"
                @keydown.escape.window="saSidebarOpen = false"
            >
                <div class="h-16 px-6 flex items-center justify-between border-b border-slate-200">
                    <div class="flex items-center gap-3">
                        <span class="h-10 w-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black">
                            SA
                        </span>
                        <div class="leading-tight">
                            <div class="text-sm font-black text-slate-900">{{ $displayName }}</div>
                            <div class="text-xs font-bold text-slate-500 uppercase tracking-widest">Super Admin</div>
                            <div class="text-[10px] text-slate-400 mt-0.5">Platform control</div>
                        </div>
                    </div>
                    <button type="button" class="rounded-lg border border-slate-300 px-2 py-1 text-xs text-slate-700" @click="saSidebarOpen = false">
                        Close
                    </button>
                </div>

                <nav class="flex-1 px-4 py-5 space-y-2 overflow-y-auto">
                    <a
                        href="{{ route('superadmin.dashboard') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                            {{ request()->routeIs('superadmin.dashboard') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
                        </svg>
                        Platform overview
                    </a>

                    <a
                        href="{{ route('superadmin.users.index') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                            {{ request()->routeIs('superadmin.users.*') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        Users
                    </a>

                    <a href="{{ route('superadmin.access_approvals') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.access_approvals') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" /></svg>
                        Access approvals
                    </a>
                    <a href="{{ route('superadmin.roles_permissions') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.roles_permissions') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z" /></svg>
                        Roles & permissions
                    </a>
                    <a href="{{ route('superadmin.agent_workspaces') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.agent_workspaces') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7H4m16 0l-2 12H6L4 7m5 0V5a3 3 0 016 0v2" /></svg>
                        Agent workspaces
                    </a>
                    <a href="{{ route('superadmin.audit_trail') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.audit_trail') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        Audit trail
                    </a>
                    <a href="{{ route('superadmin.ops.index') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.ops.*') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        Operations console
                    </a>

                    <div class="border-t border-slate-200 my-2"></div>
                    
                    <div class="px-4 py-2">
                        <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Subscriptions</div>
                    </div>
                    
                    <a href="{{ route('superadmin.console.packages') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.console.packages*') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        Subscription Packages
                    </a>
                    
                    <a href="{{ route('superadmin.console.subscriptions') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition {{ request()->routeIs('superadmin.console.subscriptions*') ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'text-slate-700 hover:bg-slate-50 border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                        Agent Subscriptions
                    </a>

                    <a
                        href="{{ route('dashboard') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50 border border-transparent transition"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                        </svg>
                        Back to dashboard
                    </a>
                </nav>
            </aside>

            {{-- Sidebar --}}
            <aside
                class="superadmin-sidebar hidden lg:flex flex-col border-r border-[#264040] bg-[#2f4f4f] text-[#d4e4e3] sticky top-0 h-screen overflow-y-auto transition-all duration-300 shadow-xl shadow-black/15"
                :class="saSidebarDesktopOpen ? 'w-[18rem] min-w-[18rem] max-w-[18rem] opacity-100' : 'w-[5.5rem] min-w-[5.5rem] max-w-[5.5rem] opacity-100'"
                :style="window.matchMedia('(min-width: 1024px)').matches
                    ? (saSidebarDesktopOpen
                        ? 'width: 18rem; min-width: 18rem; max-width: 18rem;'
                        : 'width: 5.5rem; min-width: 5.5rem; max-width: 5.5rem;')
                    : ''"
                :data-collapsed="saSidebarDesktopOpen ? '0' : '1'"
            >
                <div class="h-16 px-4 flex items-center justify-between border-b border-[#264040] bg-[#243d3d]/55">
                    <div class="flex items-center gap-3 sa-collapse-center">
                        <span class="h-10 w-10 rounded-xl bg-emerald-500/25 border border-emerald-400/35 text-emerald-200 flex items-center justify-center font-black">
                            SA
                        </span>
                        <div class="sa-collapse-text leading-tight">
                            <div class="text-sm font-black text-white">{{ $displayName }}</div>
                            <div class="text-xs font-bold text-[#8db1af] uppercase tracking-widest">Super Admin</div>
                            <div class="text-[10px] text-[#8db1af]/90 mt-0.5">Platform control</div>
                        </div>
                    </div>
                    <button
                        type="button"
                        class="inline-flex items-center justify-center rounded-lg p-2 text-[#8db1af] hover:text-white hover:bg-[#406866] transition-colors"
                        @click="toggleSaDesktopSidebar()"
                        :title="saSidebarDesktopOpen ? 'Collapse sidebar' : 'Expand sidebar'"
                        :aria-label="saSidebarDesktopOpen ? 'Collapse sidebar' : 'Expand sidebar'"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path x-show="saSidebarDesktopOpen" x-cloak stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
                            <path x-show="!saSidebarDesktopOpen" x-cloak stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
                        </svg>
                    </button>
                </div>

                <nav class="flex-1 px-4 py-5 space-y-2">
                    <a
                        href="{{ route('superadmin.dashboard') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center
                            {{ request()->routeIs('superadmin.dashboard') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
                        </svg>
                        <span class="sa-collapse-text">Platform overview</span>
                    </a>

                    <a
                        href="{{ route('superadmin.users.index') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center
                            {{ request()->routeIs('superadmin.users.*') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <span class="sa-collapse-text">Users</span>
                    </a>

                    <a href="{{ route('superadmin.access_approvals') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.access_approvals') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" /></svg>
                        <span class="sa-collapse-text">Access approvals</span>
                    </a>
                    <a href="{{ route('superadmin.roles_permissions') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.roles_permissions') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z" /></svg>
                        <span class="sa-collapse-text">Roles & permissions</span>
                    </a>
                    <a href="{{ route('superadmin.agent_workspaces') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.agent_workspaces') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7H4m16 0l-2 12H6L4 7m5 0V5a3 3 0 016 0v2" /></svg>
                        <span class="sa-collapse-text">Agent workspaces</span>
                    </a>
                    <a href="{{ route('superadmin.audit_trail') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.audit_trail') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        <span class="sa-collapse-text">Audit trail</span>
                    </a>
                    <a href="{{ route('superadmin.ops.index') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.ops.*') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        <span class="sa-collapse-text">Operations console</span>
                    </a>

                    <div class="border-t border-[#406866]/40 my-2"></div>
                    
                    <div class="px-4 py-2 sa-collapse-text">
                        <div class="text-xs font-bold text-[#8db1af] uppercase tracking-widest mb-2">Subscriptions</div>
                    </div>
                    
                    <a href="{{ route('superadmin.console.packages') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.console.packages*') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        <span class="sa-collapse-text">Subscription Packages</span>
                    </a>
                    
                    <a href="{{ route('superadmin.console.subscriptions') }}" class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition sa-collapse-center {{ request()->routeIs('superadmin.console.subscriptions*') ? 'bg-[#406866]/85 text-white border border-emerald-300/40' : 'text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent' }}">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                        <span class="sa-collapse-text">Agent Subscriptions</span>
                    </a>

                    <a
                        href="{{ route('dashboard') }}"
                        class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white border border-transparent transition sa-collapse-center"
                    >
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                        </svg>
                        <span class="sa-collapse-text">Back to dashboard</span>
                    </a>
                </nav>

                <div class="border-t border-[#264040] px-4 py-4 bg-[#243d3d]/45">
                    <div class="flex items-center gap-3 sa-collapse-center">
                        <div class="h-10 w-10 rounded-full bg-emerald-500/25 border border-emerald-400/35 flex items-center justify-center font-black text-emerald-200">
                            {{ auth()->check() && auth()->user()->name ? mb_substr(auth()->user()->name, 0, 1) : 'U' }}
                        </div>
                        <div class="sa-collapse-text min-w-0">
                            <div class="text-sm font-bold text-white truncate">{{ auth()->user()->name ?? 'User' }}</div>
                            <div class="text-xs text-[#8db1af] truncate">{{ auth()->user()->email ?? '' }}</div>
                        </div>
                    </div>

                    <form method="POST" action="{{ route('logout') }}" class="mt-4">
                        @csrf
                        <button class="w-full rounded-xl border border-[#406866]/60 bg-[#2f4f4f] px-4 py-2.5 text-sm font-bold text-[#d4e4e3] hover:bg-[#406866]/50 hover:text-white transition-colors">
                            <span class="sa-collapse-text">Log out</span>
                        </button>
                    </form>
                </div>
            </aside>

            {{-- Main --}}
            <div class="flex-1 min-w-0 min-h-0 flex flex-col overflow-hidden">
                {{-- Header --}}
                <header class="min-h-16 border-b border-emerald-700/20 bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-700 z-20 shrink-0 text-white">
                    <div class="min-h-16 px-3 sm:px-6 lg:px-8 py-2 sm:py-0 flex items-center justify-between gap-2">
                        <div class="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                            <div class="lg:hidden shrink-0">
                                <button
                                    type="button"
                                    class="inline-flex items-center rounded-xl bg-white/15 ring-1 ring-white/30 px-3 py-2 text-sm font-black text-white"
                                    @click="saSidebarOpen = true"
                                >
                                    SA
                                </button>
                            </div>
                            <div class="min-w-0 flex-1">
                                <div class="text-[10px] sm:text-sm font-bold text-emerald-100 uppercase tracking-widest">Super Admin</div>
                                <div class="text-sm sm:text-lg font-black text-white leading-snug break-words">{{ $title ?? 'Console' }}</div>
                            </div>
                        </div>

                        <div class="flex items-center gap-1.5 sm:gap-2 shrink-0">
                            @if (request()->routeIs('superadmin.users.index'))
                                <a href="{{ route('superadmin.users.create') }}" class="inline-flex items-center whitespace-nowrap rounded-xl bg-white text-emerald-700 px-2.5 py-2 sm:px-4 sm:py-2.5 text-xs sm:text-sm font-bold hover:bg-emerald-50">
                                    Add user
                                </a>
                            @endif

                            <div class="relative">
                                <button
                                    type="button"
                                    class="inline-flex items-center gap-2 rounded-xl bg-white/15 ring-1 ring-white/30 px-3 py-2 text-sm font-semibold text-white hover:bg-white/20"
                                    @click="saProfileOpen = !saProfileOpen"
                                    aria-haspopup="menu"
                                    :aria-expanded="saProfileOpen ? 'true' : 'false'"
                                >
                                    <span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white text-emerald-700 text-xs font-black">
                                        {{ auth()->check() && auth()->user()->name ? mb_substr(auth()->user()->name, 0, 1) : 'U' }}
                                    </span>
                                    <span class="hidden sm:inline max-w-[9rem] truncate">{{ auth()->user()->name ?? 'User' }}</span>
                                    <svg class="h-4 w-4 text-white/90" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                                    </svg>
                                </button>

                                <div
                                    x-show="saProfileOpen"
                                    x-cloak
                                    @click.outside="saProfileOpen = false"
                                    @keydown.escape.window="saProfileOpen = false"
                                    class="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 bg-white shadow-lg z-50 overflow-hidden"
                                    role="menu"
                                >
                                    <div class="px-4 py-3 border-b border-slate-100">
                                        <p class="text-sm font-semibold text-slate-900 truncate">{{ auth()->user()->name ?? 'User' }}</p>
                                        <p class="text-xs text-slate-500 truncate">{{ auth()->user()->email ?? '' }}</p>
                                    </div>
                                    <a
                                        href="{{ route('profile.edit') }}"
                                        class="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50"
                                        role="menuitem"
                                        @click="saProfileOpen = false"
                                    >
                                        My profile
                                    </a>
                                    <form method="POST" action="{{ route('logout') }}" class="border-t border-slate-100">
                                        @csrf
                                        <button type="submit" class="w-full text-left px-4 py-2.5 text-sm font-medium text-rose-700 hover:bg-rose-50">
                                            Log out
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                {{-- Content --}}
                <main class="flex-1 min-w-0 overflow-y-auto overflow-x-auto overscroll-x-contain px-4 sm:px-6 lg:px-8 py-8 bg-[#f4f7fa]">
                    @if (session('success'))
                        <div class="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-800">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if ($errors->any())
                        <div class="mb-6 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-rose-800 text-sm">
                            <ul class="list-disc list-inside space-y-1">
                                @foreach ($errors->all() as $message)
                                    <li>{{ $message }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @yield('content')
                </main>

                {{-- Footer --}}
                <footer class="border-t border-slate-200 bg-white shrink-0">
                    <div class="px-4 sm:px-6 lg:px-8 py-4 text-xs text-slate-500 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between sm:gap-0">
                        <span class="break-words">© {{ date('Y') }} {{ $displayName }}</span>
                        <span class="font-semibold text-slate-400 shrink-0">Super Admin Console</span>
                    </div>
                </footer>
            </div>
        </div>
    </body>
</html>

