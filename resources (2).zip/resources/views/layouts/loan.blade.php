<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">
    <head>
        @php
            $appDisplayName = \App\Models\LoanSystemSetting::getValue('app_display_name', config('app.name', 'Loan Management System'));
            $faviconUrl = \App\Models\LoanSystemSetting::getValue('favicon_url', '');
            $loanContactPhone = trim((string) \App\Models\LoanSystemSetting::getValue('company_phone', ''));
            $loanContactEmail = trim((string) \App\Models\LoanSystemSetting::getValue('company_email', ''));
            $loanContactAddress = trim((string) \App\Models\LoanSystemSetting::getValue('company_address', 'Nakuru, Kenya'));
            $loanContactAddress2 = trim((string) \App\Models\LoanSystemSetting::getValue('company_address_line_2', ''));
            $faviconRaw = trim((string) $faviconUrl);
            $faviconHref = match (true) {
                $faviconRaw === '' => asset('favicon.ico'),
                \Illuminate\Support\Str::startsWith($faviconRaw, ['http://', 'https://', '//']) => $faviconRaw,
                default => asset(ltrim($faviconRaw, '/')),
            };
            $faviconVersioned = $faviconHref.'?v='.rawurlencode(substr(md5($faviconHref), 0, 12));
        @endphp
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ $appDisplayName }}</title>
        <link rel="icon" href="{{ $faviconVersioned }}">
        <link rel="shortcut icon" href="{{ $faviconVersioned }}">
        <link rel="apple-touch-icon" href="{{ $faviconVersioned }}">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        
        <style>
            [x-cloak] { display: none !important; }
            .custom-scrollbar::-webkit-scrollbar {
                width: 6px;
            }
            .custom-scrollbar::-webkit-scrollbar-track {
                background: transparent;
            }
            .custom-scrollbar::-webkit-scrollbar-thumb {
                background: #475569;
                border-radius: 10px;
            }
            .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                background: #64748b;
            }
            /* Firefox + stable gutter */
            .custom-scrollbar {
                scrollbar-width: auto;
                scrollbar-color: #475569 transparent;
                scrollbar-gutter: stable;
            }

            @media print {
                html, body {
                    height: auto !important;
                    overflow: visible !important;
                    background: #fff !important;
                }

                @page {
                    size: landscape;
                    margin: 10mm;
                }

                aside,
                .no-print,
                #global-table-print-btn {
                    display: none !important;
                }

                #loan-app-shell {
                    display: none !important;
                }

                #global-print-surface {
                    display: block !important;
                }

                .h-full,
                .flex,
                .flex-1,
                main {
                    display: block !important;
                    height: auto !important;
                    min-height: 0 !important;
                    overflow: visible !important;
                }

                main > div {
                    padding: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                }

                table {
                    width: 100% !important;
                    table-layout: auto !important;
                    border-collapse: collapse !important;
                }

                thead {
                    display: table-header-group !important;
                }

                tr {
                    page-break-inside: avoid !important;
                    break-inside: avoid !important;
                }

                th,
                td {
                    color: #000 !important;
                    font-size: 9pt !important;
                    background: #fff !important;
                    box-shadow: none !important;
                }
            }

            #global-print-surface {
                display: none;
                background: #fff;
                color: #111827;
                padding: 0;
            }
            #global-print-surface .print-head {
                border-bottom: 2px solid #1a5f7a;
                padding-bottom: 8px;
                margin-bottom: 10px;
            }
            #global-print-surface .print-head-grid {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                gap: 12px;
            }
            #global-print-surface .print-head-right {
                text-align: right;
                font-size: 10px;
                color: #475569;
                line-height: 1.35;
                max-width: 42%;
            }
            #global-print-surface .print-brand {
                font-size: 20px;
                font-weight: 700;
                color: #0f172a;
            }
            #global-print-surface .print-brand-wrap {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            #global-print-surface .print-logo {
                max-height: 28px;
                max-width: 120px;
                object-fit: contain;
            }
            #global-print-surface .print-title {
                font-size: 14px;
                font-weight: 700;
                margin-top: 4px;
            }
            #global-print-surface .print-meta {
                font-size: 10px;
                color: #64748b;
                margin-top: 2px;
            }
            #global-print-surface table {
                width: 100%;
                border-collapse: collapse;
                table-layout: auto;
            }
            #global-print-surface thead {
                display: table-header-group;
            }
            #global-print-surface tr {
                page-break-inside: avoid;
                break-inside: avoid;
            }
            #global-print-surface th,
            #global-print-surface td {
                border: 1px solid #d1d5db;
                padding: 5px;
                font-size: 9px;
                vertical-align: top;
                word-break: break-word;
            }
            #global-print-surface th {
                background: #1a5f7a;
                color: #fff;
                text-transform: uppercase;
                letter-spacing: 0.02em;
                font-size: 8px;
                text-align: left;
            }
            #global-print-surface .print-footer {
                margin-top: 8px;
                border-top: 1px solid #d1d5db;
                padding-top: 6px;
                font-size: 8px;
                color: #6b7280;
                font-style: italic;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            @media (max-width: 1024px) {
                main .mobile-table-scroll {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }
                main .mobile-table-scroll > table {
                    min-width: max-content;
                }
            }

            main table.loan-grid-lines {
                border-collapse: collapse;
                border: 1px solid #cbd5e1;
            }
            main table.loan-grid-lines th,
            main table.loan-grid-lines td {
                border: 1px solid #cbd5e1;
            }

            #loan-shell-sidebar {
                height: 100%;
                max-height: 100vh;
                min-height: 0;
                overflow: hidden;
                flex-shrink: 0;
            }
            #loan-shell-sidebar > aside {
                height: 100%;
                max-height: 100vh;
            }
            #loan-sidebar-nav {
                overscroll-behavior: contain;
                -webkit-overflow-scrolling: touch;
            }

            #loan-workspace-main {
                position: relative;
                z-index: 0;
                isolation: isolate;
            }
            #loan-global-nav-progress {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 3px;
                z-index: 45;
                pointer-events: none;
                opacity: 0;
                transition: opacity 0.15s ease;
            }
            #loan-global-nav-progress[data-active] {
                opacity: 1;
            }
            #loan-global-nav-progress > span {
                display: block;
                height: 100%;
                width: 35%;
                border-radius: 9999px;
                background: linear-gradient(90deg, #0f766e 0%, #5eead4 45%, #0f766e 90%);
                background-size: 200% 100%;
                animation: loan-frame-progress 0.9s ease-in-out infinite;
            }
            #loan-workspace-loading {
                position: absolute;
                inset: 0;
                z-index: 25;
                display: none;
                padding: 0.75rem;
                background: rgb(244 247 250 / 0.72);
                backdrop-filter: blur(1px);
            }
            #loan-workspace-loading[data-active] {
                display: block;
                pointer-events: none;
            }
            #loan-workspace-loading[data-active] .loan-workspace-loading {
                opacity: 0.55;
            }
            #loan-workspace-error {
                display: none;
            }
            #loan-workspace-error[data-active] {
                display: block;
            }
            turbo-frame#loan-main {
                display: block;
                width: 100%;
                max-width: 100%;
                min-height: 12rem;
                position: relative;
            }
            @keyframes loan-frame-progress {
                0% { background-position: 100% 0; }
                100% { background-position: -100% 0; }
            }
        </style>
    </head>
    <body
        class="font-sans antialiased h-screen overflow-hidden text-slate-900 dark:text-slate-100 selection:bg-indigo-500/30"
        x-data="{
            sidebarOpen: false,
            sidebarDesktopOpen: true,
            init() {
                const saved = window.localStorage.getItem('loan.sidebar.desktop.open');
                if (saved !== null) {
                    this.sidebarDesktopOpen = saved === '1';
                }
            },
            toggleDesktopSidebar() {
                this.sidebarDesktopOpen = !this.sidebarDesktopOpen;
                window.localStorage.setItem('loan.sidebar.desktop.open', this.sidebarDesktopOpen ? '1' : '0');
            }
        }"
    >
        <div id="loan-app-shell" class="h-full min-h-0 flex overflow-hidden bg-slate-50 dark:bg-slate-900">
            
            <!-- Loan Module Dedicated Sidebar (persists across Turbo navigations) -->
            <div id="loan-shell-sidebar" data-turbo-permanent class="h-full max-h-screen min-h-0 overflow-hidden flex-shrink-0">
                @include('layouts.loan_sidebar')
            </div>

            <!-- Main view container (Header, Content, Footer) -->
            <div class="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden bg-[#f4f7fa]">
                
                <!-- Dedicated Clean Topbar (persists across Turbo navigations) -->
                <div id="loan-shell-header" data-turbo-permanent class="shrink-0">
                    @include('layouts.loan_topbar')
                </div>

                <!-- Scrollable Content Area (Topbar/Footer remain constant) -->
                <main id="loan-workspace-main" class="relative flex-1 min-h-0 overflow-x-hidden overflow-y-auto w-full custom-scrollbar overscroll-contain">
                    <div id="loan-global-nav-progress" aria-hidden="true"><span></span></div>
                    <div id="loan-workspace-loading" aria-hidden="true">
                        <div class="loan-workspace-loading pointer-events-none" aria-hidden="true">
                            <div class="animate-pulse space-y-4 p-1">
                                <div class="h-7 w-48 max-w-[70%] rounded-lg bg-slate-200/90"></div>
                                <div class="h-4 w-full max-w-xl rounded bg-slate-200/70"></div>
                                <div class="rounded-2xl border border-slate-200/80 bg-white/70 p-4 space-y-3">
                                    @for ($i = 0; $i < 5; $i++)
                                        <div class="flex items-center gap-3">
                                            <div class="h-4 w-4 rounded bg-slate-200/90 shrink-0"></div>
                                            <div class="h-4 flex-1 rounded bg-slate-200/70"></div>
                                            <div class="h-4 w-16 rounded bg-slate-200/60 shrink-0"></div>
                                        </div>
                                    @endfor
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="loan-workspace-error" class="absolute inset-x-0 top-0 z-30 p-4 sm:p-6" aria-live="polite"></div>
                    <div class="px-4 pb-4 pt-2 sm:px-6 sm:pb-6 sm:pt-3 lg:px-8 lg:pb-8 lg:pt-4">
                        <turbo-frame id="loan-main" data-turbo-action="advance" data-turbo-cache="false">
                            <div id="loan-main-route" data-route-name="{{ Route::currentRouteName() ?? '' }}" data-page-title="{{ trim((string) ($title ?? ($header ?? ''))) }}" hidden></div>
                            <x-swal-flash />
                            @include('layouts.partials.loan_workspace_shell')
                            {{ $slot }}
                        </turbo-frame>
                    </div>
                </main>

                <!-- Dedicated Footer (persists across Turbo navigations) -->
                <div id="loan-shell-footer" data-turbo-permanent class="shrink-0">
                    @include('layouts.loan_footer')
                </div>

            </div>
        </div>
        <div id="global-print-surface" aria-hidden="true"></div>
        <script>
        (function () {
            const SEARCH_DEBOUNCE_MS = 1100;

            function wireAutoFilterForms(scopeRoot) {
                const root = scopeRoot || document;
                const forms = Array.from(root.querySelectorAll('form[method="get"]:not([data-auto-submit="off"])'));

                forms.forEach(function (form) {
                    if (form.dataset.autoSubmitBound === '1') return;
                    form.dataset.autoSubmitBound = '1';

                    const searchInputs = Array.from(form.querySelectorAll('input[name="q"], input[type="search"], input[data-auto-search="true"]'))
                        .filter(function (input) { return !input.matches('[data-auto-submit="off"]'); });
                    searchInputs.forEach(function (input) {
                        input.addEventListener('input', function () {
                            window.clearTimeout(input._autoSearchTimer);
                            input._autoSearchTimer = window.setTimeout(function () { form.requestSubmit(); }, SEARCH_DEBOUNCE_MS);
                        });
                    });

                    const autoControls = Array.from(form.querySelectorAll('select, input[type="date"], input[type="month"], input[type="number"], input[type="checkbox"], input[type="radio"]'))
                        .filter(function (el) { return !el.matches('[data-auto-submit="off"]'); });
                    autoControls.forEach(function (control) {
                        control.addEventListener('change', function () { form.requestSubmit(); });
                    });
                });
            }

            function buildPrintSurface() {
                const printSurface = document.getElementById('global-print-surface');
                if (!printSurface) return;

                const heading = document.querySelector('main h1');
                const subtitle = document.querySelector('main h1 + p');
                const tables = Array.from(document.querySelectorAll('main table'))
                    .filter(function (table) { return table.offsetParent !== null; });
                const logoImg = document.querySelector('.sidebar img, .navbar img, header img, img[alt*="logo" i], img[src*="logo" i]');

                const titleText = heading ? heading.textContent.trim() : document.title;
                const subtitleText = subtitle ? subtitle.textContent.trim() : '';
                const generatedAt = new Date().toLocaleString();
                const logoSrc = logoImg && logoImg.getAttribute('src')
                    ? new URL(logoImg.getAttribute('src'), window.location.origin).href
                    : '';
                const year = new Date().getFullYear();
                const companyName = @json($appDisplayName);
                const contactLines = [
                    @json($loanContactPhone),
                    @json($loanContactEmail),
                    @json($loanContactAddress),
                    @json($loanContactAddress2)
                ].filter(Boolean);

                let html = ''
                    + '<div class="print-head">'
                    + '<div class="print-head-grid">'
                    + '<div class="print-head-left">'
                    + '<div class="print-brand-wrap">'
                    + (logoSrc !== '' ? '<img class="print-logo" src="' + logoSrc + '" alt="Logo">' : '')
                    + '<div class="print-brand">' + (companyName || 'Gaitho Loans') + '</div>'
                    + '</div>'
                    + '<div class="print-title">' + (titleText || 'Report') + '</div>'
                    + '<div class="print-meta">' + (subtitleText ? subtitleText + ' · ' : '') + 'Generated: ' + generatedAt + '</div>'
                    + '</div>'
                    + '<div class="print-head-right">' + (contactLines.join('<br>') || 'Nakuru, Kenya') + '</div>'
                    + '</div>'
                    + '</div>';

                if (tables.length === 0) {
                    html += '<p>No table found on this page.</p>';
                } else {
                    tables.forEach(function (table, idx) {
                        if (idx > 0) html += '<div style="height:10px"></div>';
                        html += table.outerHTML;
                    });
                }

                html += '<div class="print-footer">'
                    + '<span>Copyright © ' + year + ' ' + (companyName || 'Gaitho Loans') + '. All rights reserved.</span>'
                    + '<span>Generated by system print engine</span>'
                    + '</div>';

                printSurface.innerHTML = html;
            }

            function ensureGlobalPrintButton() {
                const isDedicatedPrintPage = window.location.pathname.includes('/print');
                const existing = document.getElementById('global-table-print-btn');

                if (isDedicatedPrintPage) {
                    if (existing) existing.remove();
                    return;
                }

                if (existing) return;

                const btn = document.createElement('button');
                btn.id = 'global-table-print-btn';
                btn.type = 'button';
                btn.textContent = 'Print';
                btn.setAttribute('aria-label', 'Print current page');
                btn.style.position = 'fixed';
                btn.style.right = '16px';
                btn.style.bottom = '16px';
                btn.style.zIndex = '60';
                btn.style.padding = '10px 16px';
                btn.style.borderRadius = '10px';
                btn.style.border = '1px solid #cbd5e1';
                btn.style.background = '#0f766e';
                btn.style.color = '#ffffff';
                btn.style.fontSize = '13px';
                btn.style.fontWeight = '600';
                btn.style.boxShadow = '0 6px 16px rgba(15, 23, 42, 0.18)';
                btn.style.cursor = 'pointer';
                btn.addEventListener('click', function () {
                    buildPrintSurface();
                    window.focus();
                    setTimeout(function () { window.print(); }, 50);
                });

                document.body.appendChild(btn);
            }

            function ensureMobileTableScroll() {
                const tables = Array.from(document.querySelectorAll('main table'));
                tables.forEach(function (table) {
                    const hasScrollableParent = table.closest('.overflow-x-auto, .mobile-table-scroll');
                    if (!hasScrollableParent) {
                        const wrapper = document.createElement('div');
                        wrapper.className = 'mobile-table-scroll';
                        table.parentNode.insertBefore(wrapper, table);
                        wrapper.appendChild(table);
                        return;
                    }

                    const scrollParent = table.closest('.overflow-x-auto');
                    if (scrollParent && !scrollParent.classList.contains('mobile-table-scroll')) {
                        scrollParent.classList.add('mobile-table-scroll');
                    }
                });
            }

            function ensureTableGridLines() {
                const tables = Array.from(document.querySelectorAll('main table'));
                tables.forEach(function (table) {
                    table.classList.add('loan-grid-lines');
                });
            }

            document.addEventListener('DOMContentLoaded', ensureGlobalPrintButton);
            document.addEventListener('DOMContentLoaded', ensureMobileTableScroll);
            document.addEventListener('DOMContentLoaded', ensureTableGridLines);
            document.addEventListener('DOMContentLoaded', function () { wireAutoFilterForms(document); });
            document.addEventListener('turbo:load', ensureGlobalPrintButton);
            document.addEventListener('turbo:load', ensureMobileTableScroll);
            document.addEventListener('turbo:load', ensureTableGridLines);
            document.addEventListener('turbo:load', function () { wireAutoFilterForms(document); });
            document.addEventListener('turbo:frame-load', function (event) {
                wireAutoFilterForms(event.target);
                if (event.target && event.target.id === 'loan-main') {
                    ensureMobileTableScroll();
                    ensureTableGridLines();
                }
            });
            document.addEventListener('livewire:navigated', ensureGlobalPrintButton);
            document.addEventListener('livewire:navigated', ensureMobileTableScroll);
            document.addEventListener('livewire:navigated', ensureTableGridLines);
            document.addEventListener('livewire:navigated', function () { wireAutoFilterForms(document); });
            document.addEventListener('alpine:navigated', ensureGlobalPrintButton);
            document.addEventListener('alpine:navigated', ensureMobileTableScroll);
            document.addEventListener('alpine:navigated', ensureTableGridLines);
            document.addEventListener('alpine:navigated', function () { wireAutoFilterForms(document); });
            window.addEventListener('popstate', ensureGlobalPrintButton);
            window.addEventListener('popstate', ensureMobileTableScroll);
            window.addEventListener('popstate', ensureTableGridLines);
            window.addEventListener('popstate', function () { wireAutoFilterForms(document); });
            window.addEventListener('beforeprint', buildPrintSurface);
        })();
        </script>
    </body>
</html>
