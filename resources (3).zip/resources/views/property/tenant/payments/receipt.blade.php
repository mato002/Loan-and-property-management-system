@php($brandName = \App\Models\PropertyPortalSetting::getValue('company_name', '') ?: config('app.name', 'Property Management System'))
<x-property-layout>
    <x-slot name="header">Receipt #RCP-PAY-{{ $payment->id }}</x-slot>

    <x-property.page
        title="{{ $brandName }} Receipt"
        subtitle="Proof of payment for receipt #RCP-PAY-{{ $payment->id }}."
        class="max-w-5xl mx-auto"
    >
        <x-slot name="actions">
            <a
                href="{{ route('property.tenant.payments.receipts.download', $payment) }}"
                data-turbo="false"
                class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >Download</a>
            <button
                type="button"
                onclick="window.print()"
                class="inline-flex items-center justify-center rounded-xl border border-slate-300 dark:border-slate-600 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
            >Print / Save PDF</button>
        </x-slot>

        <div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-gradient-to-r from-indigo-50 to-white dark:from-slate-900/50 dark:to-slate-800/50 p-4">
            <div class="flex flex-wrap items-center gap-2 text-xs">
                <span class="inline-flex items-center rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300 px-3 py-1 font-semibold">Receipt: RCP-PAY-{{ $payment->id }}</span>
                <span class="inline-flex items-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 px-3 py-1 font-semibold">Total: KES {{ number_format((float) $payment->amount, 2) }}</span>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4">
                <p class="text-xs uppercase tracking-wide text-slate-500">Tenant</p>
                <p class="mt-1 font-semibold text-slate-900 dark:text-white">{{ $payment->tenant?->name ?? '—' }}</p>
                <p class="text-sm text-slate-500 dark:text-slate-400">{{ $payment->tenant?->email ?? '—' }}</p>
            </div>
            <div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4">
                <p class="text-xs uppercase tracking-wide text-slate-500">Payment details</p>
                <p class="mt-1 text-sm text-slate-700 dark:text-slate-200">Channel: <span class="font-semibold uppercase">{{ $payment->channel }}</span></p>
                <p class="text-sm text-slate-700 dark:text-slate-200">Reference: <span class="font-semibold">{{ $payment->external_ref ?: '—' }}</span></p>
                <p class="text-sm text-slate-700 dark:text-slate-200">Paid at: <span class="font-semibold">{{ $payment->paid_at?->format('Y-m-d H:i:s') ?? '—' }}</span></p>
            </div>
        </div>

        <div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 overflow-hidden">
            <table class="min-w-full text-sm">
                <thead class="bg-slate-50 dark:bg-slate-900/60 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <tr>
                        <th class="px-4 py-3">Invoice</th>
                        <th class="px-4 py-3">Allocated amount</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($payment->allocations as $allocation)
                        <tr class="border-t border-slate-100 dark:border-slate-700/80">
                            <td class="px-4 py-3 text-slate-700 dark:text-slate-200">{{ $allocation->invoice?->invoice_no ?? ('INV-'.$allocation->pm_invoice_id) }}</td>
                            <td class="px-4 py-3 font-semibold text-slate-900 dark:text-white">KES {{ number_format((float) $allocation->amount, 2) }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2" class="px-4 py-6 text-slate-500 dark:text-slate-400">No allocations recorded.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="rounded-2xl border border-dashed border-slate-300 dark:border-slate-600 bg-slate-50/50 dark:bg-slate-900/30 p-4">
            <p class="text-xs uppercase tracking-wide text-slate-500">Total paid</p>
            <p class="mt-1 text-2xl font-black text-slate-900 dark:text-white">KES {{ number_format((float) $payment->amount, 2) }}</p>
        </div>
    </x-property.page>
</x-property-layout>

