<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserModuleAccess;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rules;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'system' => ['required', 'string', 'in:property,loan'],
            'property_portal_role' => ['nullable', 'string', 'in:agent,landlord,tenant'],
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:'.User::class],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $propertyPortalRole = $request->system === 'property'
            ? ($request->input('property_portal_role') ?: 'agent')
            : null;

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'property_portal_role' => $propertyPortalRole,
        ]);

        // Registration represents initial module approval for the selected system.
        if (Schema::hasTable('user_module_accesses')) {
            UserModuleAccess::query()->updateOrCreate(
                [
                    'user_id' => $user->id,
                    'module' => $request->system,
                ],
                [
                    'status' => UserModuleAccess::STATUS_APPROVED,
                    'approved_at' => now(),
                ]
            );
        }

        event(new Registered($user));

        Auth::login($user);

        $request->session()->put('active_system', $request->system);

        return redirect(route('dashboard', absolute: false));
    }
}
