<x-loan-layout>
    <x-loan.page
        title="{{ $loan_client->full_name }}"
        subtitle="{{ $loan_client->kind === 'lead' ? 'Lead' : 'Client' }} · {{ $loan_client->client_number }}"
    >
        <x-slot name="actions">
            <a href="{{ route('loan.clients.interactions.for_client.create', $loan_client) }}" class="inline-flex items-center justify-center rounded-lg bg-[#2f4f4f] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#264040] transition-colors">
                Log interaction
            </a>
            <a href="{{ route('loan.clients.edit', $loan_client) }}" class="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors">
                Edit
            </a>
            <a href="{{ $loan_client->kind === 'lead' ? route('loan.clients.leads') : route('loan.clients.index') }}" class="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors">
                Back
            </a>
        </x-slot>

        @if ($loan_client->kind === 'lead')
            <div class="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <span>This record is a <strong>lead</strong> (status: {{ $loan_client->lead_status ?? 'new' }}).</span>
                <form method="post" action="{{ route('loan.clients.leads.convert', $loan_client) }}" class="shrink-0" data-swal-confirm="Convert this lead to a client?">
                    @csrf
                    <x-primary-button type="submit" class="bg-emerald-700 hover:bg-emerald-800">Convert to client</x-primary-button>
                </form>
            </div>
        @endif
        @php
            $loanHistory = $loan_client->loanBookLoans ?? collect();
            $activeLoans = $loanHistory->whereIn('status', [
                \App\Models\LoanBookLoan::STATUS_ACTIVE,
                \App\Models\LoanBookLoan::STATUS_PENDING_DISBURSEMENT,
                \App\Models\LoanBookLoan::STATUS_RESTRUCTURED,
            ]);
            $cyclesCount = $loanHistory->count();
            $totalOutstanding = (float) $activeLoans->sum(fn ($loan) => (float) ($loan->balance ?? 0));
            $totalRepaid = (float) $loanHistory->sum(fn ($loan) => (float) ($loan->processed_repayments_sum_amount ?? 0));
            $maxDpd = (int) $activeLoans->max(fn ($loan) => (int) ($loan->dpd ?? 0));
            $statusTone = $maxDpd > 30 ? 'text-rose-600' : ($maxDpd > 0 ? 'text-amber-600' : 'text-emerald-600');
        @endphp

        <div
            class="grid grid-cols-1 lg:grid-cols-3 gap-6"
            x-data="{
                activeLoan: null,
                detailsOpen: false,
                installmentsOpen: false,
                showDetails(payload) { this.activeLoan = payload; this.detailsOpen = true; },
                showInstallments(payload) { this.activeLoan = payload; this.installmentsOpen = true; },
                closeModals() { this.detailsOpen = false; this.installmentsOpen = false; }
            }"
        >
            <style>
                .client-loan-compact th,
                .client-loan-compact td {
                    padding-top: 0.35rem;
                    padding-bottom: 0.35rem;
                    font-size: 0.72rem;
                    line-height: 1.05rem;
                }
            </style>
            <div class="lg:col-span-2 space-y-6">
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-4">
                    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                        <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Cycles</p>
                        <p class="mt-2 text-xl font-semibold text-slate-900">{{ number_format($cyclesCount) }}</p>
                    </div>
                    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                        <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Active balance</p>
                        <p class="mt-2 text-xl font-semibold text-slate-900">{{ number_format($totalOutstanding, 2) }}</p>
                    </div>
                    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                        <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Total repaid</p>
                        <p class="mt-2 text-xl font-semibold text-slate-900">{{ number_format($totalRepaid, 2) }}</p>
                    </div>
                    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                        <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Max arrears (DPD)</p>
                        <p class="mt-2 text-xl font-semibold {{ $statusTone }}">{{ number_format($maxDpd) }}</p>
                    </div>
                </div>

                <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-5 sm:p-6">
                    <h2 class="text-sm font-semibold text-slate-700 mb-4">Profile</h2>
                    <div class="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
                        @php
                            $photoItems = [
                                ['label' => $biodataLabels['client_photo'] ?? 'Client Photo', 'path' => $loan_client->client_photo_path],
                                ['label' => $biodataLabels['id_back_photo'] ?? 'Id Back Photo', 'path' => $loan_client->id_back_photo_path],
                                ['label' => $biodataLabels['id_front_photo'] ?? 'Id Front Photo', 'path' => $loan_client->id_front_photo_path],
                            ];
                        @endphp
                        @foreach ($photoItems as $item)
                            <div class="rounded-lg border border-slate-200 bg-slate-50 p-2">
                                <p class="mb-1 text-[11px] font-semibold text-slate-600">{{ $item['label'] }}</p>
                                @if (filled($item['path']))
                                    <a href="{{ \Illuminate\Support\Facades\Storage::url($item['path']) }}" target="_blank" class="block overflow-hidden rounded border border-slate-200 bg-white">
                                        <img src="{{ \Illuminate\Support\Facades\Storage::url($item['path']) }}" alt="{{ $item['label'] }}" class="h-24 w-full object-cover" />
                                    </a>
                                @else
                                    <div class="flex h-24 items-center justify-center rounded border border-dashed border-slate-300 bg-white text-xs text-slate-400">No image</div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                    <dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                        <div><dt class="text-slate-500">{{ $biodataLabels['phone'] ?? 'Client Contact' }}</dt><dd class="text-slate-900"><x-phone-link :value="$loan_client->phone" /></dd></div>
                        <div><dt class="text-slate-500">Email</dt><dd class="text-slate-900">{{ $loan_client->email ?? '—' }}</dd></div>
                        <div><dt class="text-slate-500">{{ $biodataLabels['id_number'] ?? 'Idno' }}</dt><dd class="text-slate-900">{{ $loan_client->id_number ?? '—' }}</dd></div>
                        <div><dt class="text-slate-500">{{ $biodataLabels['gender'] ?? 'Gender' }}</dt><dd class="text-slate-900">{{ $loan_client->gender ? ucfirst($loan_client->gender) : '—' }}</dd></div>
                        <div><dt class="text-slate-500">{{ $biodataLabels['next_of_kin_contact'] ?? 'Kin Contact' }}</dt><dd class="text-slate-900"><x-phone-link :value="$loan_client->next_of_kin_contact" /></dd></div>
                        <div><dt class="text-slate-500">{{ $biodataLabels['next_of_kin_name'] ?? 'Next Of Kin' }}</dt><dd class="text-slate-900">{{ $loan_client->next_of_kin_name ?? '—' }}</dd></div>
                        <div><dt class="text-slate-500">Branch</dt><dd class="text-slate-900">{{ $loan_client->branch ?? '—' }}</dd></div>
                        <div class="sm:col-span-2"><dt class="text-slate-500">Address</dt><dd class="text-slate-900 whitespace-pre-line">{{ $loan_client->address ?? '—' }}</dd></div>
                        <div><dt class="text-slate-500">{{ $biodataLabels['assigned_employee_id'] ?? 'Loan Officer' }}</dt><dd class="text-slate-900">{{ $loan_client->assignedEmployee?->full_name ?? '—' }}</dd></div>
                        @if ($loan_client->kind === 'client')
                            <div><dt class="text-slate-500">Client status</dt><dd class="text-slate-900">{{ $loan_client->client_status }}</dd></div>
                            @if ($loan_client->converted_at)
                                <div class="sm:col-span-2"><dt class="text-slate-500">Converted from lead</dt><dd class="text-slate-900">{{ $loan_client->converted_at->format('M j, Y H:i') }}</dd></div>
                            @endif
                        @endif
                    </dl>
                    @php
                        $extraMeta = collect((array) ($loan_client->biodata_meta ?? []))
                            ->filter(fn ($value) => filled($value));
                    @endphp
                    @if ($extraMeta->isNotEmpty())
                        <div class="mt-4 pt-4 border-t border-slate-100">
                            <h3 class="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Additional biodata fields</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                @foreach ($extraMeta as $key => $value)
                                    @php
                                        $label = ucfirst(str_replace('_', ' ', (string) $key));
                                        $stringValue = is_scalar($value) ? trim((string) $value) : '';
                                        $isImagePath = $stringValue !== '' && (str_contains(strtolower($stringValue), '.jpg') || str_contains(strtolower($stringValue), '.jpeg') || str_contains(strtolower($stringValue), '.png') || str_contains(strtolower($stringValue), '.webp'));
                                    @endphp
                                    <div>
                                        <p class="text-slate-500">{{ $label }}</p>
                                        @if ($isImagePath)
                                            <a href="{{ \Illuminate\Support\Facades\Storage::url($stringValue) }}" target="_blank" class="mt-1 block overflow-hidden rounded border border-slate-200 bg-white">
                                                <img src="{{ \Illuminate\Support\Facades\Storage::url($stringValue) }}" alt="{{ $label }}" class="h-20 w-full object-cover" />
                                            </a>
                                        @else
                                            <p class="text-slate-900 whitespace-pre-line">{{ $stringValue !== '' ? $stringValue : '—' }}</p>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @php
                        $guarantorAttrs = [
                            'guarantor_1_full_name', 'guarantor_1_phone', 'guarantor_1_id_number', 'guarantor_1_relationship', 'guarantor_1_address',
                            'guarantor_2_full_name', 'guarantor_2_phone', 'guarantor_2_id_number', 'guarantor_2_relationship', 'guarantor_2_address',
                        ];
                        $hasGuarantorInfo = collect($guarantorAttrs)->contains(fn ($a) => filled($loan_client->{$a}));
                    @endphp
                    @if ($hasGuarantorInfo)
                        <div class="mt-4 pt-4 border-t border-slate-100">
                            <h3 class="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Guarantors</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                                @if (collect(['guarantor_1_full_name', 'guarantor_1_phone', 'guarantor_1_id_number', 'guarantor_1_relationship', 'guarantor_1_address'])->contains(fn ($a) => filled($loan_client->{$a})))
                                    <div class="rounded-lg border border-slate-100 bg-slate-50/80 p-4 space-y-2">
                                        <p class="text-xs font-semibold text-slate-600 uppercase tracking-wide">Guarantor 1</p>
                                        @if (filled($loan_client->guarantor_1_full_name))<div><span class="text-slate-500">Name</span><p class="text-slate-900">{{ $loan_client->guarantor_1_full_name }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_1_phone))<div><span class="text-slate-500">Phone</span><p class="text-slate-900"><x-phone-link :value="$loan_client->guarantor_1_phone" /></p></div>@endif
                                        @if (filled($loan_client->guarantor_1_id_number))<div><span class="text-slate-500">ID / registration</span><p class="text-slate-900">{{ $loan_client->guarantor_1_id_number }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_1_relationship))<div><span class="text-slate-500">Relationship</span><p class="text-slate-900">{{ $loan_client->guarantor_1_relationship }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_1_address))<div class="sm:col-span-2"><span class="text-slate-500">Address</span><p class="text-slate-900 whitespace-pre-line">{{ $loan_client->guarantor_1_address }}</p></div>@endif
                                    </div>
                                @endif
                                @if (collect(['guarantor_2_full_name', 'guarantor_2_phone', 'guarantor_2_id_number', 'guarantor_2_relationship', 'guarantor_2_address'])->contains(fn ($a) => filled($loan_client->{$a})))
                                    <div class="rounded-lg border border-slate-100 bg-slate-50/80 p-4 space-y-2">
                                        <p class="text-xs font-semibold text-slate-600 uppercase tracking-wide">Guarantor 2</p>
                                        @if (filled($loan_client->guarantor_2_full_name))<div><span class="text-slate-500">Name</span><p class="text-slate-900">{{ $loan_client->guarantor_2_full_name }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_2_phone))<div><span class="text-slate-500">Phone</span><p class="text-slate-900"><x-phone-link :value="$loan_client->guarantor_2_phone" /></p></div>@endif
                                        @if (filled($loan_client->guarantor_2_id_number))<div><span class="text-slate-500">ID / registration</span><p class="text-slate-900">{{ $loan_client->guarantor_2_id_number }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_2_relationship))<div><span class="text-slate-500">Relationship</span><p class="text-slate-900">{{ $loan_client->guarantor_2_relationship }}</p></div>@endif
                                        @if (filled($loan_client->guarantor_2_address))<div class="sm:col-span-2"><span class="text-slate-500">Address</span><p class="text-slate-900 whitespace-pre-line">{{ $loan_client->guarantor_2_address }}</p></div>@endif
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endif

                    @if ($loan_client->notes)
                        <div class="mt-4 pt-4 border-t border-slate-100">
                            <p class="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Notes</p>
                            <p class="text-sm text-slate-700 whitespace-pre-line">{{ $loan_client->notes }}</p>
                        </div>
                    @endif
                </div>

                <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                        <h2 class="text-sm font-semibold text-slate-700">Loan history</h2>
                        <span class="text-xs text-slate-500">{{ $loanHistory->count() }} record(s)</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="client-loan-compact min-w-full divide-y divide-slate-100 text-xs">
                            <thead class="bg-slate-50 text-slate-600">
                                <tr>
                                    <th class="px-3 py-2 text-left font-semibold">Date</th>
                                    <th class="px-3 py-2 text-left font-semibold">Loan</th>
                                    <th class="px-3 py-2 text-left font-semibold">Product</th>
                                    <th class="px-3 py-2 text-right font-semibold">Principal</th>
                                    <th class="px-3 py-2 text-right font-semibold">Balance</th>
                                    <th class="px-3 py-2 text-right font-semibold">Repaid</th>
                                    <th class="px-3 py-2 text-right font-semibold">DPD</th>
                                    <th class="px-3 py-2 text-left font-semibold">Status</th>
                                    <th class="px-3 py-2 text-left font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                                @forelse ($loanHistory as $loan)
                                    @php
                                        $paymentsForModal = $loan->processedRepayments ?? collect();
                                        $runningPaid = 0.0;
                                        $installmentsPayload = $paymentsForModal->map(function ($payment) use ($loan, &$runningPaid) {
                                            $amount = (float) ($payment->amount ?? 0);
                                            $runningPaid += $amount;
                                            $balanceAfter = max(0, (float) ($loan->principal ?? 0) - $runningPaid);
                                            return [
                                                'date' => optional($payment->transaction_at)->format('Y-m-d') ?? '',
                                                'reference' => (string) ($payment->reference ?? ''),
                                                'amount' => $amount,
                                                'balance_after' => $balanceAfter,
                                            ];
                                        })->values()->all();
                                        $loanModalPayload = [
                                            'loan_number' => (string) ($loan->loan_number ?? ''),
                                            'product_name' => (string) ($loan->product_name ?? ''),
                                            'status' => ucfirst(str_replace('_', ' ', (string) ($loan->status ?? ''))),
                                            'principal' => (float) ($loan->principal ?? 0),
                                            'balance' => (float) ($loan->balance ?? 0),
                                            'interest_rate' => (float) ($loan->interest_rate ?? 0),
                                            'term_value' => (int) ($loan->term_value ?? 0),
                                            'term_unit' => (string) ($loan->term_unit ?? ''),
                                            'disbursed_at' => optional($loan->disbursed_at)->format('Y-m-d H:i') ?? '',
                                            'maturity_date' => optional($loan->maturity_date)->format('Y-m-d') ?? '',
                                            'dpd' => (int) ($loan->dpd ?? 0),
                                            'repayments_count' => (int) $paymentsForModal->count(),
                                            'repaid_total' => (float) ($loan->processed_repayments_sum_amount ?? 0),
                                            'branch' => (string) ($loan->branch ?? ''),
                                            'notes' => (string) ($loan->notes ?? ''),
                                            'disbursements' => ($loan->disbursements ?? collect())->map(fn ($d) => [
                                                'date' => optional($d->disbursed_at)->format('Y-m-d') ?? '',
                                                'amount' => (float) ($d->amount ?? 0),
                                                'method' => (string) ($d->method ?? ''),
                                                'reference' => (string) ($d->reference ?? ''),
                                            ])->values()->all(),
                                            'installments' => $installmentsPayload,
                                        ];
                                    @endphp
                                    <tr>
                                        <td class="px-3 py-2 whitespace-nowrap">{{ optional($loan->disbursed_at)->format('M j, Y') ?? '—' }}</td>
                                        <td class="px-3 py-2 whitespace-nowrap">
                                            @if ($loan->loan_number)
                                                <button type="button" @click="showDetails(@js($loanModalPayload))" class="font-mono text-indigo-600 hover:underline">{{ $loan->loan_number }}</button>
                                                <a href="{{ route('loan.book.loans.show', $loan) }}" class="ml-1 text-[11px] text-slate-400 hover:text-slate-600" title="Open full loan page">↗</a>
                                            @else
                                                —
                                            @endif
                                        </td>
                                        <td class="px-3 py-2 whitespace-nowrap">{{ $loan->product_name ?: '—' }}</td>
                                        <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($loan->principal ?? 0), 2) }}</td>
                                        <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($loan->balance ?? 0), 2) }}</td>
                                        <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($loan->processed_repayments_sum_amount ?? 0), 2) }}</td>
                                        <td class="px-3 py-2 text-right tabular-nums">{{ (int) ($loan->dpd ?? 0) }}</td>
                                        <td class="px-3 py-2 whitespace-nowrap">
                                            @php
                                                $statusKey = (string) ($loan->status ?? '');
                                                $statusBadge = match ($statusKey) {
                                                    \App\Models\LoanBookLoan::STATUS_ACTIVE => 'bg-emerald-50 text-emerald-700',
                                                    \App\Models\LoanBookLoan::STATUS_PENDING_DISBURSEMENT => 'bg-amber-50 text-amber-700',
                                                    \App\Models\LoanBookLoan::STATUS_RESTRUCTURED => 'bg-indigo-50 text-indigo-700',
                                                    \App\Models\LoanBookLoan::STATUS_CLOSED => 'bg-slate-100 text-slate-700',
                                                    \App\Models\LoanBookLoan::STATUS_WRITTEN_OFF => 'bg-rose-50 text-rose-700',
                                                    default => 'bg-slate-100 text-slate-700',
                                                };
                                                $statusDot = match ($statusKey) {
                                                    \App\Models\LoanBookLoan::STATUS_ACTIVE => 'bg-emerald-500',
                                                    \App\Models\LoanBookLoan::STATUS_PENDING_DISBURSEMENT => 'bg-amber-500',
                                                    \App\Models\LoanBookLoan::STATUS_RESTRUCTURED => 'bg-indigo-500',
                                                    \App\Models\LoanBookLoan::STATUS_CLOSED => 'bg-slate-400',
                                                    \App\Models\LoanBookLoan::STATUS_WRITTEN_OFF => 'bg-rose-500',
                                                    default => 'bg-slate-400',
                                                };
                                            @endphp
                                            <span class="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium {{ $statusBadge }}">
                                                <span class="h-1.5 w-1.5 rounded-full {{ $statusDot }}"></span>
                                                {{ ucfirst(str_replace('_', ' ', (string) $loan->status)) }}
                                            </span>
                                        </td>
                                        <td class="px-3 py-2 whitespace-nowrap">
                                            <button type="button" @click="showDetails(@js($loanModalPayload))" class="text-indigo-600 hover:underline mr-2">View</button>
                                            <button type="button" @click="showInstallments(@js($loanModalPayload))" class="text-[#2f4f4f] hover:underline">Schedule</button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="px-3 py-8 text-center text-sm text-slate-500">No loan history recorded.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                        <h2 class="text-sm font-semibold text-slate-700">Applications</h2>
                        <span class="text-xs text-slate-500">{{ ($recentApplications ?? collect())->count() }} recent</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-slate-100 text-xs">
                            <thead class="bg-slate-50 text-slate-600">
                                <tr>
                                    <th class="px-3 py-2 text-left font-semibold">Reference</th>
                                    <th class="px-3 py-2 text-left font-semibold">Product</th>
                                    <th class="px-3 py-2 text-right font-semibold">Amount</th>
                                    <th class="px-3 py-2 text-left font-semibold">Stage</th>
                                    <th class="px-3 py-2 text-left font-semibold">Submitted</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                                @forelse (($recentApplications ?? collect()) as $application)
                                    <tr>
                                        <td class="px-3 py-2 whitespace-nowrap">
                                            <a href="{{ route('loan.book.applications.show', $application) }}" class="text-indigo-600 hover:underline">{{ $application->reference }}</a>
                                        </td>
                                        <td class="px-3 py-2">{{ $application->product_name ?: '—' }}</td>
                                        <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($application->amount_requested ?? 0), 2) }}</td>
                                        <td class="px-3 py-2">{{ ucfirst(str_replace('_', ' ', (string) $application->stage)) }}</td>
                                        <td class="px-3 py-2 whitespace-nowrap">{{ optional($application->submitted_at)->format('M j, Y') ?? '—' }}</td>
                                    </tr>
                                @empty
                                    <tr><td colspan="5" class="px-3 py-8 text-center text-sm text-slate-500">No applications found.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">
                    <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                        <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                            <h2 class="text-sm font-semibold text-slate-700">Payments</h2>
                            <span class="text-xs text-slate-500">{{ ($recentPayments ?? collect())->count() }} recent</span>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-slate-100 text-xs">
                                <thead class="bg-slate-50 text-slate-600">
                                    <tr>
                                        <th class="px-3 py-2 text-left font-semibold">Reference</th>
                                        <th class="px-3 py-2 text-right font-semibold">Amount</th>
                                        <th class="px-3 py-2 text-left font-semibold">Channel</th>
                                        <th class="px-3 py-2 text-left font-semibold">Date</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                                    @forelse (($recentPayments ?? collect()) as $payment)
                                        <tr>
                                            <td class="px-3 py-2 font-mono">{{ $payment->reference ?: '—' }}</td>
                                            <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($payment->amount ?? 0), 2) }}</td>
                                            <td class="px-3 py-2">{{ $payment->channel ?: '—' }}</td>
                                            <td class="px-3 py-2 whitespace-nowrap">{{ optional($payment->transaction_at)->format('M j, Y H:i') ?? '—' }}</td>
                                        </tr>
                                    @empty
                                        <tr><td colspan="4" class="px-3 py-8 text-center text-sm text-slate-500">No payments found.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                        <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                            <h2 class="text-sm font-semibold text-slate-700">Disbursements</h2>
                            <span class="text-xs text-slate-500">{{ ($recentDisbursements ?? collect())->count() }} recent</span>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-slate-100 text-xs">
                                <thead class="bg-slate-50 text-slate-600">
                                    <tr>
                                        <th class="px-3 py-2 text-left font-semibold">Loan</th>
                                        <th class="px-3 py-2 text-right font-semibold">Amount</th>
                                        <th class="px-3 py-2 text-left font-semibold">Method</th>
                                        <th class="px-3 py-2 text-left font-semibold">Date</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                                    @forelse (($recentDisbursements ?? collect()) as $disbursement)
                                        <tr>
                                            <td class="px-3 py-2 font-mono">
                                                @if ($disbursement->loan)
                                                    <a href="{{ route('loan.book.loans.show', $disbursement->loan) }}" class="text-indigo-600 hover:underline">{{ $disbursement->loan->loan_number }}</a>
                                                @else
                                                    —
                                                @endif
                                            </td>
                                            <td class="px-3 py-2 text-right tabular-nums">{{ number_format((float) ($disbursement->amount ?? 0), 2) }}</td>
                                            <td class="px-3 py-2">{{ $disbursement->method ?: '—' }}</td>
                                            <td class="px-3 py-2 whitespace-nowrap">{{ optional($disbursement->disbursed_at)->format('M j, Y') ?? '—' }}</td>
                                        </tr>
                                    @empty
                                        <tr><td colspan="4" class="px-3 py-8 text-center text-sm text-slate-500">No disbursements found.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                        <h2 class="text-sm font-semibold text-slate-700">Recent interactions</h2>
                        <a href="{{ route('loan.clients.interactions') }}" class="text-xs font-medium text-indigo-600 hover:text-indigo-500">View all</a>
                    </div>
                    <ul class="divide-y divide-slate-100">
                        @forelse ($loan_client->interactions->take(8) as $interaction)
                            <li class="px-5 py-3 text-sm">
                                <div class="flex flex-wrap items-baseline justify-between gap-2">
                                    <span class="font-medium text-slate-900">{{ ucfirst($interaction->interaction_type) }}</span>
                                    <span class="text-xs text-slate-500">{{ $interaction->interacted_at->format('M j, Y H:i') }}</span>
                                </div>
                                @if ($interaction->subject)
                                    <p class="text-slate-700 mt-0.5">{{ $interaction->subject }}</p>
                                @endif
                                @if ($interaction->notes)
                                    <p class="text-slate-600 text-xs mt-1 whitespace-pre-line">{{ $interaction->notes }}</p>
                                @endif
                                <p class="text-xs text-slate-400 mt-1">By {{ $interaction->user?->name ?? 'System' }}</p>
                            </li>
                        @empty
                            <li class="px-5 py-8 text-center text-slate-500 text-sm">No interactions logged yet.</li>
                        @endforelse
                    </ul>
                </div>
            </div>

            <div class="space-y-6">
                @if ($loan_client->kind === 'client' && $loan_client->defaultGroups->isNotEmpty())
                    <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-5">
                        <h2 class="text-sm font-semibold text-slate-700 mb-3">Default groups</h2>
                        <ul class="space-y-2 text-sm">
                            @foreach ($loan_client->defaultGroups as $group)
                                <li>
                                    <a href="{{ route('loan.clients.default_groups.show', $group) }}" class="text-indigo-600 hover:text-indigo-500 font-medium">{{ $group->name }}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-5">
                    <h2 class="text-sm font-semibold text-slate-700 mb-3">Transfer history</h2>
                    @php $transfers = $loan_client->transfers()->with(['fromEmployee', 'toEmployee', 'transferredByUser'])->limit(10)->get(); @endphp
                    <ul class="space-y-3 text-xs text-slate-600">
                        @forelse ($transfers as $t)
                            <li class="border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                                <p>{{ $t->created_at->format('M j, Y') }} · {{ $t->transferredByUser?->name ?? 'User' }}</p>
                                <p>Branch: {{ $t->from_branch ?? '—' }} → {{ $t->to_branch ?? '—' }}</p>
                                <p>Officer: {{ $t->fromEmployee?->full_name ?? '—' }} → {{ $t->toEmployee?->full_name ?? '—' }}</p>
                                @if ($t->reason)<p class="mt-1 text-slate-500">{{ $t->reason }}</p>@endif
                            </li>
                        @empty
                            <li class="text-slate-500">No transfers recorded.</li>
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div x-show="detailsOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4" @keydown.escape.window="closeModals()" @click.self="closeModals()">
            <div class="w-full max-w-3xl rounded-xl bg-white shadow-2xl max-h-[90vh] overflow-y-auto">
                <div class="flex items-center justify-between border-b border-slate-100 px-5 py-3">
                    <h3 class="text-base font-semibold text-slate-800">Loan details</h3>
                    <button type="button" @click="closeModals()" class="text-slate-400 hover:text-slate-700">✕</button>
                </div>
                <div class="p-5 text-sm text-slate-700">
                    <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <p><span class="font-semibold text-slate-600">Loan #:</span> <span x-text="activeLoan?.loan_number || '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">Product:</span> <span x-text="activeLoan?.product_name || '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">Principal:</span> <span x-text="Number(activeLoan?.principal || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></span></p>
                        <p><span class="font-semibold text-slate-600">Balance:</span> <span x-text="Number(activeLoan?.balance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></span></p>
                        <p><span class="font-semibold text-slate-600">Interest rate:</span> <span x-text="activeLoan?.interest_rate !== undefined ? activeLoan.interest_rate + '%' : '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">Term:</span> <span x-text="(activeLoan?.term_value || 0) + ' ' + (activeLoan?.term_unit || '')"></span></p>
                        <p><span class="font-semibold text-slate-600">Disbursed:</span> <span x-text="activeLoan?.disbursed_at || '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">Maturity:</span> <span x-text="activeLoan?.maturity_date || '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">Status:</span> <span x-text="activeLoan?.status || '—'"></span></p>
                        <p><span class="font-semibold text-slate-600">DPD:</span> <span x-text="activeLoan?.dpd ?? 0"></span></p>
                        <p><span class="font-semibold text-slate-600">Total repaid:</span> <span x-text="Number(activeLoan?.repaid_total || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></span></p>
                        <p><span class="font-semibold text-slate-600">Repayments count:</span> <span x-text="activeLoan?.repayments_count ?? 0"></span></p>
                    </div>
                    <template x-if="(activeLoan?.disbursements || []).length > 0">
                        <div class="mt-4 border-t border-slate-100 pt-4">
                            <h4 class="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Disbursements</h4>
                            <div class="space-y-1 text-xs">
                                <template x-for="item in (activeLoan?.disbursements || [])" :key="item.date + '-' + item.reference">
                                    <p><span x-text="item.date || '—'"></span> · <span x-text="item.method || '—'"></span> · <span x-text="Number(item.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></span></p>
                                </template>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <div x-show="installmentsOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4" @keydown.escape.window="closeModals()" @click.self="closeModals()">
            <div class="w-full max-w-4xl rounded-xl bg-white shadow-2xl max-h-[90vh] overflow-y-auto">
                <div class="flex items-center justify-between border-b border-slate-100 px-5 py-3">
                    <h3 class="text-base font-semibold text-slate-800">Loan installments / repayments</h3>
                    <button type="button" @click="closeModals()" class="text-slate-400 hover:text-slate-700">✕</button>
                </div>
                <div class="p-5">
                    <p class="mb-3 text-sm text-slate-700"><span class="font-semibold text-slate-600">Loan #:</span> <span x-text="activeLoan?.loan_number || '—'"></span></p>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-slate-100 text-xs">
                            <thead class="bg-slate-50 text-slate-600">
                                <tr>
                                    <th class="px-3 py-2 text-left font-semibold">Date</th>
                                    <th class="px-3 py-2 text-left font-semibold">Reference</th>
                                    <th class="px-3 py-2 text-right font-semibold">Amount</th>
                                    <th class="px-3 py-2 text-right font-semibold">Balance after</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 bg-white text-slate-700">
                                <template x-if="(activeLoan?.installments || []).length === 0">
                                    <tr><td colspan="4" class="px-3 py-8 text-center text-slate-500">No repayment entries yet.</td></tr>
                                </template>
                                <template x-for="row in (activeLoan?.installments || [])" :key="row.date + '-' + row.reference">
                                    <tr>
                                        <td class="px-3 py-2 whitespace-nowrap" x-text="row.date || '—'"></td>
                                        <td class="px-3 py-2 font-mono" x-text="row.reference || '—'"></td>
                                        <td class="px-3 py-2 text-right tabular-nums" x-text="Number(row.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></td>
                                        <td class="px-3 py-2 text-right tabular-nums" x-text="Number(row.balance_after || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })"></td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </x-loan.page>
</x-loan-layout>
