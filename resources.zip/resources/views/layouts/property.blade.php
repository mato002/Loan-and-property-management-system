<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">
    <head>
        @php
            $siteFaviconUrl = \App\Models\PropertyPortalSetting::getValue('site_favicon_url', '');
            $faviconHref = $siteFaviconUrl !== '' ? $siteFaviconUrl : asset('favicon.ico');
            $faviconVersioned = $faviconHref.'?v='.rawurlencode(substr(md5($faviconHref), 0, 12));
        @endphp
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Property Management System</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <link rel="icon" href="{{ $faviconVersioned }}" />
        <link rel="shortcut icon" href="{{ $faviconVersioned }}" />
        <link rel="apple-touch-icon" href="{{ $faviconVersioned }}" />
        
        <style>
            [x-cloak] { display: none !important; }
            .custom-scrollbar::-webkit-scrollbar {
                width: 6px;
                height: 6px;
            }
            .custom-scrollbar::-webkit-scrollbar-track {
                background: transparent;
            }
            .custom-scrollbar::-webkit-scrollbar-thumb {
                background: #b8c2ce;
                border-radius: 10px;
            }
            .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                background: #94a3b8;
            }
            /* Firefox */
            .custom-scrollbar {
                scrollbar-width: auto;
                scrollbar-color: #b8c2ce transparent;
                scrollbar-gutter: stable;
            }
            @media print {
                @page { size: auto; margin: 12mm; }
                html, body {
                    background: #fff !important;
                    color: #000 !important;
                    height: auto !important;
                    overflow: visible !important;
                }
                .property-print-hide,
                .print-hide {
                    display: none !important;
                }
                .property-print-only {
                    display: block !important;
                }
                .property-print-root {
                    display: block !important;
                    width: 100% !important;
                    min-height: auto !important;
                }
                .property-print-main {
                    overflow: visible !important;
                    padding: 0 !important;
                    margin: 0 !important;
                }
                #property-main {
                    display: block !important;
                    width: 100% !important;
                }
                a {
                    text-decoration: none !important;
                    color: #000 !important;
                }
                .shadow-sm, .shadow, .shadow-lg, .rounded-2xl, .rounded-xl, .rounded-lg {
                    box-shadow: none !important;
                }
            }
            .property-print-only {
                display: none;
            }
        </style>
    </head>
    <body class="font-sans antialiased h-screen overflow-hidden text-slate-900 bg-[#e8ecf1] selection:bg-emerald-200/80 @if(($propertyPortal ?? 'agent') === 'tenant') selection:bg-teal-200 @endif" x-data="{ sidebarOpen: false }">
        <div class="h-full flex property-print-root">
            
            <!-- Property Module Dedicated Sidebar -->
            <div class="property-print-hide">
                @include('layouts.property_sidebar')
            </div>

            <!-- Main view container (Header, Content, Footer) -->
            <div class="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">
                
                <!-- Dedicated Header -->
                <div class="property-print-hide">
                    @include('layouts.property_header')
                </div>

                <!-- Scrollable Content Area (Header/Footer remain constant) -->
                <main class="property-print-main relative z-0 flex-1 min-h-0 overflow-x-hidden overflow-y-auto w-full custom-scrollbar">
                    <div class="p-4 sm:p-6 lg:p-8 w-full">
                        <turbo-frame id="property-main" data-turbo-action="advance">
                            <div id="property-main-route" data-route-name="{{ Route::currentRouteName() ?? '' }}" hidden></div>
                            <x-property.next-steps-modal />
                            <x-swal-flash />
                            {{ $slot }}
                        </turbo-frame>
                    </div>
                </main>

                <!-- Dedicated Footer (constant) -->
                <div class="property-print-hide">
                    @include('layouts.property_footer')
                </div>

            </div>
        </div>

        @if (($propertyPortal ?? 'agent') === 'agent')
            <a
                href="{{ route('property.advisor') }}"
                data-turbo-frame="property-main"
                class="property-print-hide fixed bottom-5 right-5 z-30 flex items-center gap-2 rounded-full bg-violet-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-900/40 ring-2 ring-white/20 hover:bg-violet-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-violet-300 transition-colors"
                title="AI advisor"
            >
                <i class="fa-solid fa-robot text-lg" aria-hidden="true"></i>
                <span class="hidden sm:inline">Ask</span>
            </a>
        @endif

        @stack('scripts')
    </body>
</html>
