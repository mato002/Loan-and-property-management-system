<turbo-frame id="property-dashboard-stats">
    @include('property.agent.partials.dashboard_stats_inner')
</turbo-frame>
