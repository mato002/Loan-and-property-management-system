<x-property-layout>
    <x-slot name="header">Dashboard</x-slot>

    <x-property.page
        title="Dashboard"
        subtitle="Portfolio snapshot — counts, cash movement, maintenance intake, and year-to-date billing vs collections."
    >
        <turbo-frame id="property-dashboard-stats" src="{{ route('property.dashboard.stats') }}">
            @include('property.agent.partials.dashboard_stats_skeleton')
        </turbo-frame>
    </x-property.page>
</x-property-layout>
