<x-property.workspace
    title="Edit unit"
    subtitle="Update unit details such as label, type, bedrooms, rent, and status."
    back-route="property.properties.units"
    :stats="[
        ['label' => 'Property', 'value' => $unit->property?->name ?? '—', 'hint' => 'Building'],
        ['label' => 'Unit', 'value' => $unit->label, 'hint' => 'Current label'],
    ]"
    :columns="[]"
>
    <form method="post" action="{{ route('property.units.update', $unit) }}" class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-5 shadow-sm space-y-3 max-w-2xl">
        @csrf
        @method('PATCH')
        <h3 class="text-sm font-semibold text-slate-900 dark:text-white">Unit details</h3>

        <div class="grid gap-3 sm:grid-cols-2">
            <div>
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Property</label>
                <input type="text" value="{{ $unit->property?->name }}" disabled class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-100 dark:bg-gray-900/50 text-sm px-3 py-2 text-slate-600 dark:text-slate-300" />
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Label <span class="text-red-600">*</span></label>
                <input type="text" name="label" value="{{ old('label', $unit->label) }}" required class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2" />
                @error('label')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Unit type <span class="text-red-600">*</span></label>
                <select id="unit_type" name="unit_type" required class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2">
                    @foreach ($unitTypes as $typeValue => $typeLabel)
                        <option value="{{ $typeValue }}" @selected(old('unit_type', $unit->unit_type) === $typeValue)>{{ $typeLabel }}</option>
                    @endforeach
                </select>
                @error('unit_type')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
            <div id="bedrooms_wrapper">
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Bedrooms / room setup <span class="text-red-600">*</span></label>
                <select id="bedrooms" name="bedrooms" class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2">
                    <option value="0" @selected((string) old('bedrooms', $unit->bedrooms) === '0')>No separate bedroom</option>
                    @for ($b = 1; $b <= 10; $b++)
                        <option value="{{ $b }}" @selected((string) old('bedrooms', $unit->bedrooms) === (string) $b)>{{ $b }} {{ Str::plural('bedroom', $b) }}</option>
                    @endfor
                </select>
                @error('bedrooms')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Rent (KES) <span class="text-red-600">*</span></label>
                <input type="number" name="rent_amount" value="{{ old('rent_amount', $unit->rent_amount) }}" step="0.01" min="0" required class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2" />
                @error('rent_amount')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Status <span class="text-red-600">*</span></label>
                <select name="status" required class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2">
                    <option value="vacant" @selected(old('status', $unit->status) === 'vacant')>Vacant</option>
                    <option value="occupied" @selected(old('status', $unit->status) === 'occupied')>Occupied</option>
                    <option value="notice" @selected(old('status', $unit->status) === 'notice')>Notice</option>
                </select>
                @error('status')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
            <div class="sm:col-span-2">
                <label class="block text-xs font-medium text-slate-600 dark:text-slate-400">Public listing description</label>
                <textarea
                    name="public_listing_description"
                    rows="5"
                    class="mt-1 w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-gray-900 text-sm px-3 py-2"
                    placeholder="Describe highlights seen on the public property page."
                >{{ old('public_listing_description', $unit->public_listing_description) }}</textarea>
                @error('public_listing_description')<p class="text-xs text-red-600 mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="flex gap-2">
            <button type="submit" class="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">Save changes</button>
            <a href="{{ route('property.properties.units', ['property_id' => $unit->property_id], absolute: false) }}" data-turbo-frame="property-main" class="rounded-xl border border-slate-300 dark:border-slate-600 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">Cancel</a>
        </div>
    </form>

    <script>
        (() => {
            const unitType = document.getElementById('unit_type');
            const bedrooms = document.getElementById('bedrooms');
            const bedroomsWrapper = document.getElementById('bedrooms_wrapper');
            if (!unitType || !bedrooms || !bedroomsWrapper) {
                return;
            }

            const noBedroomTypes = new Set(['single_room', 'bedsitter', 'studio']);
            const syncBedrooms = () => {
                const requiresNoBedroom = noBedroomTypes.has(unitType.value);
                if (requiresNoBedroom) {
                    bedrooms.value = '0';
                    bedrooms.disabled = true;
                    bedroomsWrapper.classList.add('hidden');
                } else {
                    bedrooms.disabled = false;
                    bedroomsWrapper.classList.remove('hidden');
                }
            };

            unitType.addEventListener('change', syncBedrooms);
            syncBedrooms();
        })();
    </script>
</x-property.workspace>
