@php($title = 'Audit Trail — Super Admin')
@extends('layouts.superadmin', ['title' => $title])

@section('content')
    <div class="mb-6">
        <h1 class="text-2xl font-black tracking-tight text-slate-900">Audit trail</h1>
        <p class="mt-1 text-sm text-slate-600">Recent portal actions across users.</p>
    </div>

    @if (! $tablesReady)
        <div class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-amber-800">`pm_portal_actions` table is not available yet.</div>
    @else
        <form method="get" class="mb-4">
            <input
                type="text"
                name="q"
                value="{{ $q }}"
                placeholder="Search action key, notes, role..."
                class="w-full sm:max-w-md rounded-xl border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
        </form>

        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <table class="w-full text-sm">
                <thead class="bg-slate-50 text-slate-600">
                    <tr>
                        <th class="px-5 py-3 text-left font-bold">When</th>
                        <th class="px-5 py-3 text-left font-bold">User</th>
                        <th class="px-5 py-3 text-left font-bold">Role</th>
                        <th class="px-5 py-3 text-left font-bold">Action key</th>
                        <th class="px-5 py-3 text-left font-bold">Notes</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse ($items as $item)
                        <tr>
                            <td class="px-5 py-3">{{ optional($item->created_at)->format('Y-m-d H:i') }}</td>
                            <td class="px-5 py-3">
                                <div class="font-semibold text-slate-900">{{ $item->user?->name ?? '—' }}</div>
                                <div class="text-xs text-slate-500">{{ $item->user?->email ?? '' }}</div>
                            </td>
                            <td class="px-5 py-3">{{ $item->portal_role }}</td>
                            <td class="px-5 py-3">{{ $item->action_key }}</td>
                            <td class="px-5 py-3">{{ \Illuminate\Support\Str::limit((string) ($item->notes ?? '—'), 90) }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="px-5 py-10 text-center text-slate-500">No actions found.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            {{ $items->links() }}
        </div>
    @endif
@endsection

