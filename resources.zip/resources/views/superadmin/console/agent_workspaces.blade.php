@php($title = 'Agent Workspaces — Super Admin')
@extends('layouts.superadmin', ['title' => $title])

@section('content')
    <div class="mb-6">
        <h1 class="text-2xl font-black tracking-tight text-slate-900">Agent workspaces</h1>
        <p class="mt-1 text-sm text-slate-600">Ownership footprint per agent account.</p>
    </div>

    <form method="get" class="mb-4">
        <div class="inline-flex rounded-xl border border-slate-300 bg-white p-1">
            <button name="workspace" value="all" class="rounded-lg px-3 py-1.5 text-xs font-bold {{ ($workspace ?? 'all') === 'all' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-50' }}">All</button>
            <button name="workspace" value="active" class="rounded-lg px-3 py-1.5 text-xs font-bold {{ ($workspace ?? 'all') === 'active' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-50' }}">Active workspaces</button>
            <button name="workspace" value="empty" class="rounded-lg px-3 py-1.5 text-xs font-bold {{ ($workspace ?? 'all') === 'empty' ? 'bg-emerald-600 text-white' : 'text-slate-700 hover:bg-slate-50' }}">Empty workspaces</button>
        </div>
    </form>

    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-600">
                <tr>
                    <th class="px-5 py-3 text-left font-bold">Agent</th>
                    <th class="px-5 py-3 text-right font-bold">Properties</th>
                    <th class="px-5 py-3 text-right font-bold">Units</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse ($agents as $agent)
                    <tr>
                        <td class="px-5 py-4">
                            <div class="font-semibold text-slate-900">{{ $agent->name }}</div>
                            <div class="text-slate-500">{{ $agent->email }}</div>
                        </td>
                        <td class="px-5 py-4 text-right">{{ (int) ($propertyCounts[$agent->id] ?? 0) }}</td>
                        <td class="px-5 py-4 text-right">{{ (int) ($unitCounts[$agent->id] ?? 0) }}</td>
                    </tr>
                @empty
                    <tr><td colspan="3" class="px-5 py-10 text-center text-slate-500">No agents found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection

