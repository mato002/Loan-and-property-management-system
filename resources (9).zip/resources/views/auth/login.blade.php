<x-workspace-login-layout :title="__('Sign in').' — '.config('app.name')">
    @php
        $companyName = \App\Models\PropertyPortalSetting::getValue('company_name', '') ?: config('app.name');
        $hour = now()->hour;
        $greeting = $hour < 12 ? __('Good morning') : ($hour < 17 ? __('Good afternoon') : __('Good evening'));
        $emailErr = $errors->first('email');
        $passErr = $errors->first('password');
        $moduleErr = $errors->first('module');
    @endphp

    <div class="rounded-2xl border border-slate-200/90 bg-white/95 p-6 shadow-[0_16px_48px_-20px_rgba(12,61,54,0.22)] ring-1 ring-black/[0.04] backdrop-blur-sm sm:p-8">
        <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
            <a
                href="{{ url('/') }}"
                class="inline-flex items-center gap-2 rounded-lg border border-slate-200/90 bg-slate-50/80 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:border-[#0B7A5A]/35 hover:bg-white hover:text-[#0B7A5A] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0B7A5A]/30 focus-visible:ring-offset-2"
            >
                <svg class="h-4 w-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
                </svg>
                {{ __('Back to home') }}
            </a>
            @if (Route::has('register'))
                <p class="text-xs text-slate-500">
                    {{ __('Not a member?') }}
                    <a href="{{ route('register') }}" class="font-semibold text-[#0B7A5A] underline-offset-2 hover:text-[#085f46] hover:underline">{{ __('Sign up') }}</a>
                </p>
            @endif
        </div>

        <div class="mb-6 flex flex-wrap items-center gap-2">
            <span class="inline-flex items-center rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-600">{{ __('Operations') }}</span>
            <span class="text-xs font-medium text-slate-500">{{ $companyName }}</span>
        </div>

        <p class="text-xs font-medium text-slate-500">{{ $greeting }} — {{ now()->timezone(config('app.timezone'))->isoFormat('MMM D') }}</p>
        <h1 class="mt-1 text-xl font-bold tracking-tight text-[#0c3d36] sm:text-2xl">{{ __('Welcome back') }}</h1>
        <p class="mt-1.5 text-sm leading-relaxed text-slate-600">
            {{ __('Access your operations workspace with your staff credentials.') }}
        </p>

        @if ($moduleErr)
            <div class="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800" role="alert">
                {{ $moduleErr }}
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}" class="mt-8 space-y-5" x-data="{ showPassword: false }">
            @csrf

            <div class="space-y-1.5">
                <label for="email" class="text-xs font-semibold text-slate-600">{{ __('Email') }}</label>
                <div class="relative flex items-center gap-3 rounded-xl border bg-white px-3.5 py-2.5 transition {{ $emailErr ? 'border-red-400 ring-2 ring-red-100' : 'border-slate-200 focus-within:border-[#0B7A5A] focus-within:ring-2 focus-within:ring-[#0B7A5A]/15' }}">
                    <span class="text-slate-400" aria-hidden="true">
                        <svg class="h-5 w-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                        </svg>
                    </span>
                    <input
                        id="email"
                        name="email"
                        type="email"
                        value="{{ old('email') }}"
                        required
                        autocomplete="username"
                        placeholder="name@company.com"
                        class="min-w-0 flex-1 border-0 bg-transparent p-0 text-[15px] text-slate-900 placeholder:text-slate-400 focus:ring-0"
                    />
                </div>
                @if ($emailErr)
                    <p class="text-xs text-red-600">{{ $emailErr }}</p>
                @endif
            </div>

            <div class="space-y-1.5">
                <label for="password" class="text-xs font-semibold text-slate-600">{{ __('Password') }}</label>
                <div class="relative flex items-center gap-3 rounded-xl border bg-white px-3.5 py-2.5 transition {{ $passErr ? 'border-red-400 ring-2 ring-red-100' : 'border-slate-200 focus-within:border-[#0B7A5A] focus-within:ring-2 focus-within:ring-[#0B7A5A]/15' }}">
                    <span class="text-slate-400" aria-hidden="true">
                        <svg class="h-5 w-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                        </svg>
                    </span>
                    <input
                        id="password"
                        name="password"
                        x-bind:type="showPassword ? 'text' : 'password'"
                        required
                        autocomplete="current-password"
                        class="min-w-0 flex-1 border-0 bg-transparent p-0 text-[15px] text-slate-900 placeholder:text-slate-400 focus:ring-0"
                        placeholder="••••••••"
                    />
                    <button
                        type="button"
                        class="shrink-0 rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0B7A5A]/25"
                        @click="showPassword = !showPassword"
                        :aria-pressed="showPassword"
                        aria-label="{{ __('Toggle password visibility') }}"
                    >
                        <svg x-show="!showPassword" class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                        <svg x-cloak x-show="showPassword" class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m12.74 12.74L21 21" />
                        </svg>
                    </button>
                </div>
                @if ($passErr)
                    <p class="text-xs text-red-600">{{ $passErr }}</p>
                @endif
            </div>

            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <label class="inline-flex cursor-pointer select-none items-center gap-2.5 text-sm text-slate-600">
                    <input id="remember_me" type="checkbox" name="remember" class="h-4 w-4 rounded border-slate-300 text-[#0B7A5A] focus:ring-[#0B7A5A]/30" />
                    <span>{{ __('Remember me') }}</span>
                </label>
                @if (Route::has('password.request'))
                    <a href="{{ route('password.request') }}" class="text-sm font-semibold text-[#0B7A5A] underline-offset-2 hover:text-[#085f46] hover:underline sm:text-right">{{ __('Forgot password?') }}</a>
                @endif
            </div>

            <button
                type="submit"
                class="group relative flex w-full min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#0B7A5A] px-4 py-3.5 text-[15px] font-semibold text-white shadow-md shadow-[#0B7A5A]/25 transition hover:bg-[#085f46] hover:shadow-lg hover:shadow-[#0B7A5A]/30 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0B7A5A] focus-visible:ring-offset-2 active:scale-[0.99]"
            >
                {{ __('Access workspace') }}
                <svg class="h-5 w-5 transition group-hover:translate-x-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                </svg>
            </button>
        </form>

        <div class="mt-8 border-t border-slate-100 pt-6">
            <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{{ __('Quick access') }}</p>
            <div class="mt-2.5 flex flex-wrap gap-2">
                <a
                    href="{{ route('property.tenant.login') }}"
                    class="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 shadow-sm transition hover:border-[#0B7A5A]/40 hover:text-[#0B7A5A] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0B7A5A]/25 focus-visible:ring-offset-2"
                >
                    {{ __('Tenant portal') }}
                </a>
                <a
                    href="{{ route('property.landlord.login') }}"
                    class="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 shadow-sm transition hover:border-[#0B7A5A]/40 hover:text-[#0B7A5A] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0B7A5A]/25 focus-visible:ring-offset-2"
                >
                    {{ __('Landlord portal') }}
                </a>
            </div>
        </div>
    </div>
</x-workspace-login-layout>
