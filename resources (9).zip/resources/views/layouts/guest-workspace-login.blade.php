<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @php
            $companyName = \App\Models\PropertyPortalSetting::getValue('company_name', '') ?: config('app.name');
            $companyLogoUrl = trim((string) \App\Models\PropertyPortalSetting::getValue('company_logo_url', ''));
            $siteFaviconUrl = \App\Models\PropertyPortalSetting::getValue('site_favicon_url', '');
            $faviconHref = $siteFaviconUrl !== '' ? $siteFaviconUrl : asset('favicon.ico');
            $faviconVersioned = $faviconHref.'?v='.rawurlencode(substr(md5($faviconHref), 0, 12));
            $resolvedTitle = str_replace(config('app.name'), $companyName, $title);
            $heroImage = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ef?auto=format&fit=crop&w=1600&q=80';
        @endphp
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ $resolvedTitle }}</title>
        <link rel="icon" href="{{ $faviconVersioned }}" />
        <link rel="shortcut icon" href="{{ $faviconVersioned }}" />
        <link rel="apple-touch-icon" href="{{ $faviconVersioned }}" />

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700&display=swap" rel="stylesheet" />

        @vite(['resources/css/app.css', 'resources/js/app.js'])
        <style>[x-cloak]{display:none!important}</style>
    </head>
    <body class="min-h-screen antialiased bg-[#eef1f0] text-slate-900" style="font-family: 'Plus Jakarta Sans', ui-sans-serif, system-ui, sans-serif;">
        <x-swal-flash />
        <div class="relative min-h-screen flex flex-col">
            {{-- Subtle grid texture --}}
            <div class="pointer-events-none fixed inset-0 opacity-[0.35]" aria-hidden="true" style="background-image: linear-gradient(rgba(11,122,90,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(11,122,90,0.03) 1px, transparent 1px); background-size: 48px 48px;"></div>

            <main class="relative z-10 flex flex-1 flex-col items-center px-4 py-8 sm:px-6 sm:py-10 lg:py-12">
                <div class="w-full max-w-5xl flex-1 flex flex-col">
                    {{-- Brand header --}}
                    <header class="mb-8 flex flex-col items-center gap-4 text-center sm:mb-10 lg:mb-12">
                        <div class="flex flex-col items-center gap-3">
                            @if ($companyLogoUrl !== '')
                                <img src="{{ $companyLogoUrl }}" alt="{{ $companyName }}" class="h-10 w-auto max-w-[200px] object-contain sm:h-11" />
                            @else
                                <div class="rounded-lg border border-slate-200/80 bg-white px-4 py-2 text-sm font-bold tracking-tight text-[#0c3d36] shadow-sm">
                                    {{ $companyName }}
                                </div>
                            @endif
                            <div class="flex flex-wrap items-center justify-center gap-2">
                                <span class="inline-flex items-center rounded-full border border-[#0B7A5A]/20 bg-[#0B7A5A]/08 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[#0B7A5A]">{{ __('Workspace') }}</span>
                                <span class="hidden h-1 w-1 rounded-full bg-slate-300 sm:inline" aria-hidden="true"></span>
                                <span class="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">{{ __('Property operations platform') }}</span>
                            </div>
                        </div>
                    </header>

                    {{-- Two-column workspace --}}
                    <div class="grid flex-1 grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-10 lg:items-stretch">
                        {{-- Left: mobile banner first, then desktop narrative + visual --}}
                        <div class="flex flex-col gap-5 lg:col-span-5">
                            {{-- Mobile compact banner --}}
                            <div class="lg:hidden overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm">
                                <div class="relative h-28">
                                    <img src="{{ $heroImage }}" alt="" class="h-full w-full object-cover" loading="lazy" decoding="async" />
                                    <div class="absolute inset-0 bg-gradient-to-r from-[#0c3d36]/95 via-[#0B7A5A]/88 to-[#0B7A5A]/75"></div>
                                    <div class="absolute inset-0 flex items-center justify-between gap-2 px-4">
                                        <p class="text-xs font-medium leading-snug text-white/95">{{ __('Operations, finance, and portfolios in one secure workspace.') }}</p>
                                    </div>
                                </div>
                                <div class="flex gap-2 overflow-x-auto px-3 py-2.5">
                                    <span class="shrink-0 rounded-lg bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600 ring-1 ring-slate-200/80">{{ __('Properties') }}</span>
                                    <span class="shrink-0 rounded-lg bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600 ring-1 ring-slate-200/80">{{ __('Tenants') }}</span>
                                    <span class="shrink-0 rounded-lg bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600 ring-1 ring-slate-200/80">{{ __('Accounting') }}</span>
                                    <span class="shrink-0 rounded-lg bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600 ring-1 ring-slate-200/80">{{ __('Reports') }}</span>
                                </div>
                            </div>

                            {{-- Desktop left panel --}}
                            <div class="hidden min-h-[420px] flex-col overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-[0_12px_40px_-12px_rgba(15,60,55,0.18)] ring-1 ring-black/[0.03] lg:flex">
                                <div class="relative flex-1 overflow-hidden">
                                    <img src="{{ $heroImage }}" alt="" class="absolute inset-0 h-full w-full object-cover" loading="lazy" decoding="async" />
                                    <div class="absolute inset-0 bg-gradient-to-t from-[#061a18] via-[#0c3d36]/88 to-[#0B7A5A]/55"></div>
                                    <div class="relative flex h-full min-h-[320px] flex-col justify-between p-7 text-white">
                                        <div>
                                            <p class="text-[11px] font-semibold uppercase tracking-[0.2em] text-white/70">{{ __('Platform') }}</p>
                                            <h2 class="mt-3 max-w-sm text-xl font-bold leading-snug tracking-tight sm:text-2xl">
                                                {{ __('Property operations & financial control in one place.') }}
                                            </h2>
                                            <p class="mt-3 max-w-sm text-sm leading-relaxed text-white/85">
                                                {{ __('Secure workspace access for property teams and stakeholders.') }}
                                            </p>
                                        </div>
                                        <ul class="space-y-2.5 text-sm font-medium text-white/95">
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Properties') }}
                                            </li>
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Tenants') }}
                                            </li>
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Accounting') }}
                                            </li>
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Maintenance') }}
                                            </li>
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Payroll') }}
                                            </li>
                                            <li class="flex items-center gap-2.5">
                                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#c9a227]/25 text-[#f0d78c]" aria-hidden="true">✓</span>
                                                {{ __('Reports') }}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="relative border-t border-slate-200/60 bg-slate-50/90 p-5 backdrop-blur-sm">
                                    <div class="grid grid-cols-3 gap-3">
                                        <div class="rounded-xl border border-white/80 bg-white/90 p-3 shadow-sm ring-1 ring-slate-200/50 backdrop-blur-md">
                                            <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{{ __('Occupancy') }}</p>
                                            <p class="mt-1 text-lg font-bold tabular-nums text-[#0c3d36]">92%</p>
                                        </div>
                                        <div class="rounded-xl border border-white/80 bg-white/90 p-3 shadow-sm ring-1 ring-slate-200/50 backdrop-blur-md">
                                            <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{{ __('Rent collected') }}</p>
                                            <p class="mt-1 text-sm font-bold tabular-nums leading-tight text-[#0c3d36]">{{ __('KES 4.2M') }}</p>
                                        </div>
                                        <div class="rounded-xl border border-white/80 bg-white/90 p-3 shadow-sm ring-1 ring-slate-200/50 backdrop-blur-md">
                                            <p class="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{{ __('Maintenance') }}</p>
                                            <p class="mt-1 text-lg font-bold tabular-nums text-[#0c3d36]">12</p>
                                            <p class="text-[9px] font-medium text-slate-400">{{ __('open') }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Right: sign-in card --}}
                        <div class="lg:col-span-7 flex flex-col justify-center">
                            <div class="mx-auto w-full max-w-md lg:max-w-none">
                                {{ $slot }}
                            </div>
                        </div>
                    </div>

                    <footer class="mt-auto pt-10 pb-2 text-center">
                        <div class="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px] text-slate-500">
                            <span class="inline-flex items-center gap-1.5 rounded-full border border-slate-200/90 bg-white/80 px-2.5 py-1 text-slate-600 shadow-sm">
                                <svg class="h-3.5 w-3.5 text-[#0B7A5A]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1Zm3 8V5.5a3 3 0 1 0-6 0V9h6Z" clip-rule="evenodd" /></svg>
                                {{ __('TLS encrypted session') }}
                            </span>
                            <span class="hidden sm:inline text-slate-300" aria-hidden="true">·</span>
                            <span>{{ __('All systems operational') }}</span>
                        </div>
                        <p class="mt-3 text-[10px] text-slate-400">{{ $companyName }} · {{ date('Y') }}</p>
                    </footer>
                </div>
            </main>
        </div>
    </body>
</html>
