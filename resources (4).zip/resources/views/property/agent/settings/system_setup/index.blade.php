<x-property-layout>
    <x-slot name="header">System setup</x-slot>

    <x-property.page
        title="System setup"
        subtitle="Manage global form behavior, workflow automation, and document templates used across the portal."
    >
        <div class="mb-4 flex flex-wrap gap-2">
            <a href="{{ route('property.settings.roles') }}" class="rounded-lg border border-slate-200 dark:border-slate-600 px-3 py-1.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">Property users</a>
            <a href="{{ route('property.settings.commission') }}" class="rounded-lg border border-slate-200 dark:border-slate-600 px-3 py-1.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">Commission</a>
            <a href="{{ route('property.settings.payments') }}" class="rounded-lg border border-slate-200 dark:border-slate-600 px-3 py-1.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">Payment config</a>
            <a href="{{ route('property.settings.branding') }}" class="rounded-lg border border-slate-200 dark:border-slate-600 px-3 py-1.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">Branding</a>
            <a href="{{ route('property.settings.rules') }}" class="rounded-lg border border-slate-200 dark:border-slate-600 px-3 py-1.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50">System rules</a>
            <a href="{{ route('property.settings.system_setup') }}" aria-current="page" class="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white">System setup</a>
        </div>

        <x-property.hub-grid :items="[
            ['route' => 'property.settings.system_setup.property_onboarding_fields', 'title' => 'Property onboarding fields', 'description' => 'Define exact fields shown when creating/onboarding a property.'],
            ['route' => 'property.settings.system_setup.unit_fields', 'title' => 'Unit fields', 'description' => 'Configure fields used when adding or editing units.'],
            ['route' => 'property.settings.system_setup.amenity_fields', 'title' => 'Amenity fields', 'description' => 'Define amenity creation fields and optional metadata.'],
            ['route' => 'property.settings.system_setup.landlord_fields', 'title' => 'Landlord fields', 'description' => 'Configure landlord onboarding and profile fields.'],
            ['route' => 'property.settings.system_setup.lead_fields', 'title' => 'Leads fields', 'description' => 'Configure listing lead capture and qualification fields.'],
            ['route' => 'property.settings.system_setup.rental_application_fields', 'title' => 'Rental application fields', 'description' => 'Configure rental application screening fields.'],
            ['route' => 'property.settings.system_setup.tenant_fields', 'title' => 'Tenant fields', 'description' => 'Configure tenant onboarding and profile fields.'],
            ['route' => 'property.settings.system_setup.lease_fields', 'title' => 'Lease fields', 'description' => 'Configure lease setup fields and required inputs.'],
            ['route' => 'property.settings.system_setup.forms', 'title' => 'General form switches', 'description' => 'Enable/disable broad form modules and shared JSON mappings.'],
            ['route' => 'property.settings.system_setup.workflows', 'title' => 'Workflow adjustments', 'description' => 'Automation toggles for assignment and reminders.'],
            ['route' => 'property.settings.system_setup.templates', 'title' => 'Template adjustments', 'description' => 'Default lease and notice text used by forms.'],
            ['route' => 'property.settings.system_setup.access', 'title' => 'Access control', 'description' => 'Create roles, permissions, and user role mappings.'],
        ]" />

        <div class="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Forms configured</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $formsCount }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Property onboarding fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $propertyOnboardingFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Unit fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $unitFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Amenity fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $amenityFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Landlord fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $landlordFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Lead fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $leadFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Rental application fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $rentalApplicationFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Tenant fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $tenantFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Lease fields</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $leaseFieldsCount ?? 0 }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Workflow rules</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $workflowsCount }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Templates configured</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $templatesCount }}</p>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-gray-800/80 p-4 shadow-sm">
                <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Roles configured</p>
                <p class="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{{ $accessCount ?? 0 }}</p>
            </div>
        </div>
    </x-property.page>
</x-property-layout>

