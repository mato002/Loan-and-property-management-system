<?php

namespace App\Http\Controllers\Property\Agent;

use App\Http\Controllers\Controller;
use App\Models\PmMaintenanceJob;
use App\Models\PmLease;
use App\Models\PmMaintenanceRequest;
use App\Models\PmMessageLog;
use App\Models\PmVendor;
use App\Models\PropertyPortalSetting;
use App\Models\PropertyUnit;
use App\Support\CsvExport;
use App\Services\Property\PropertyAccountingPostingService;
use App\Services\Property\PropertyMoney;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Collection;
use Illuminate\Support\HtmlString;
use Illuminate\Support\Str;
use Illuminate\View\View;

class PmMaintenanceWebController extends Controller
{
    private function notifyTenantProgress(PmMaintenanceRequest $requestItem, string $subject, string $body): void
    {
        $requestItem->loadMissing(['reportedBy', 'unit.property']);
        $userId = (int) ($requestItem->reported_by_user_id ?? 0);
        if ($userId <= 0) {
            return;
        }

        PmMessageLog::query()->create([
            'user_id' => $userId,
            'channel' => 'system',
            'to_address' => (string) ($requestItem->reportedBy?->email ?? ('user:'.$userId)),
            'subject' => $subject,
            'body' => $body,
            'delivery_status' => 'sent',
            'delivery_error' => null,
            'sent_at' => now(),
        ]);
    }

    public function requests(Request $request): View
    {
        $maintenanceEnabled = PropertyPortalSetting::getValue('form_maintenance_enabled', '1') === '1';
        $workflowAutoAssignTickets = PropertyPortalSetting::getValue('workflow_auto_assign_tickets', '0') === '1';
        $filters = $request->only(['q', 'status', 'urgency', 'unit_id', 'from', 'to', 'sort', 'dir', 'per_page']);
        $requestQuery = $this->requestsQuery($filters);
        $statsSource = (clone $requestQuery)->get();
        $perPage = $this->listPerPage($filters);
        $requests = $requestQuery->paginate($perPage)->withQueryString();

        $stats = [
            ['label' => 'Open', 'value' => (string) $statsSource->where('status', 'open')->count(), 'hint' => ''],
            ['label' => 'In progress', 'value' => (string) $statsSource->where('status', 'in_progress')->count(), 'hint' => ''],
            ['label' => 'Done', 'value' => (string) $statsSource->where('status', 'done')->count(), 'hint' => ''],
            ['label' => 'Total', 'value' => (string) $statsSource->count(), 'hint' => 'Filtered'],
        ];

        $rows = $requests->getCollection()->map(function (PmMaintenanceRequest $r) {
            $actionsBody = '<a href="'.route('property.maintenance.requests.edit', $r).'" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">Edit</a>';
            if (! in_array($r->status, ['done', 'closed'], true)) {
                $actionsBody .=
                    '<form method="POST" action="'.route('property.maintenance.requests.status', ['requestItem' => $r]).'" class="block">'.csrf_field().
                    '<input type="hidden" name="status" value="in_progress" />'.
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50">Triage</button>'.
                    '</form>'.
                    '<form method="POST" action="'.route('property.maintenance.requests.status', ['requestItem' => $r]).'" class="block">'.csrf_field().
                    '<input type="hidden" name="status" value="done" />'.
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-emerald-700 hover:bg-emerald-50">Resolve</button>'.
                    '</form>';
            }

            $actions = new HtmlString(
                '<div class="relative inline-block text-left">'.
                '<details>'.
                '<summary class="list-none cursor-pointer rounded border border-slate-300 px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50">Actions <span class="text-slate-400">▼</span></summary>'.
                '<div class="absolute right-0 z-30 mt-1 w-40 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-lg">'.
                $actionsBody.
                '</div>'.
                '</details>'.
                '</div>'
            );

            return [
                '#'.$r->id,
                $r->unit->property->name.'/'.$r->unit->label,
                $r->category,
                Str::limit($r->description, 40),
                $r->created_at->format('Y-m-d'),
                ucfirst($r->urgency),
                ucfirst(str_replace('_', ' ', $r->status)),
                $r->reportedBy?->name ?? '—',
                $actions,
            ];
        })->all();

        return property_view('property.agent.maintenance.requests', [
            'stats' => $stats,
            'columns' => ['ID', 'Unit', 'Category', 'Summary', 'Reported', 'Priority', 'Status', 'Assignee', 'Actions'],
            'tableRows' => $rows,
            'units' => PropertyUnit::query()->with('property')->orderBy('property_id')->get(),
            'maintenanceEnabled' => $maintenanceEnabled,
            'workflowAutoAssignTickets' => $workflowAutoAssignTickets,
            'filters' => [...$filters, 'per_page' => $perPage],
            'requestPager' => $requests,
        ]);
    }

    public function requestsExport(Request $request)
    {
        $filters = $request->only(['q', 'status', 'urgency', 'unit_id', 'from', 'to', 'sort', 'dir']);
        $rows = $this->requestsQuery($filters)->get();

        return CsvExport::stream(
            'maintenance_requests_'.now()->format('Ymd_His').'.csv',
            ['ID', 'Unit', 'Category', 'Description', 'Urgency', 'Status', 'Reported By', 'Created At'],
            function () use ($rows) {
                foreach ($rows as $r) {
                    yield [
                        $r->id,
                        $r->unit->property->name.'/'.$r->unit->label,
                        $r->category,
                        $r->description,
                        $r->urgency,
                        $r->status,
                        $r->reportedBy?->name,
                        optional($r->created_at)->format('Y-m-d H:i:s'),
                    ];
                }
            }
        );
    }

    public function storeRequest(Request $request): RedirectResponse
    {
        if (PropertyPortalSetting::getValue('form_maintenance_enabled', '1') !== '1') {
            return back()->with('error', __('Maintenance request form is disabled in System setup.'));
        }
        $workflowAutoAssignTickets = PropertyPortalSetting::getValue('workflow_auto_assign_tickets', '0') === '1';

        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'property_unit_id' => [
                'required',
                Rule::exists('property_units', 'id')->where(fn ($q) => $q->where('property_id', (int) $request->input('property_id'))),
            ],
            'category' => ['required', 'string', 'max:64'],
            'description' => ['required', 'string', 'max:5000'],
            'urgency' => ['required', 'in:normal,urgent,emergency'],
        ]);

        $pmTenantId = $this->resolveTenantIdForMaintenanceUnit((int) $data['property_unit_id']);

        PmMaintenanceRequest::query()->create([
            'property_unit_id' => (int) $data['property_unit_id'],
            'pm_tenant_id' => $pmTenantId,
            'reported_by_user_id' => $request->user()->id,
            // Auto-assign behavior is represented by moving new tickets into triage immediately.
            'status' => $workflowAutoAssignTickets ? 'in_progress' : 'open',
            'category' => (string) $data['category'],
            'description' => (string) $data['description'],
            'urgency' => (string) $data['urgency'],
        ]);

        return back()->with(
            'success',
            $workflowAutoAssignTickets
                ? 'Maintenance request logged and auto-routed to triage.'
                : 'Maintenance request logged.'
        );
    }

    public function updateRequestStatus(Request $request, PmMaintenanceRequest $requestItem): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', 'in:open,in_progress,done,closed'],
        ]);

        $oldStatus = (string) $requestItem->status;
        $requestItem->update([
            'status' => $data['status'],
        ]);
        $newStatus = (string) $data['status'];
        if ($oldStatus !== $newStatus) {
            $unitLabel = (string) optional($requestItem->unit?->property)->name.'/'.(optional($requestItem->unit)->label ?? '—');
            $this->notifyTenantProgress(
                $requestItem,
                'Maintenance request #'.$requestItem->id.' update',
                'Your request at '.$unitLabel.' moved from '
                .str_replace('_', ' ', $oldStatus)
                .' to '
                .str_replace('_', ' ', $newStatus)
                .'.'
            );
        }

        return back()->with('success', 'Request status updated.');
    }

    public function editRequest(PmMaintenanceRequest $requestItem): View
    {
        $requestItem->load(['unit.property', 'reportedBy']);

        return property_view('property.agent.maintenance.request_edit', [
            'requestItem' => $requestItem,
            'units' => PropertyUnit::query()->with('property')->orderBy('property_id')->orderBy('label')->get(),
        ]);
    }

    public function updateRequest(Request $request, PmMaintenanceRequest $requestItem): RedirectResponse
    {
        $data = $request->validate([
            'property_unit_id' => ['required', 'exists:property_units,id'],
            'category' => ['required', 'string', 'max:64'],
            'description' => ['required', 'string', 'max:5000'],
            'urgency' => ['required', 'in:normal,urgent,emergency'],
            'status' => ['required', 'in:open,in_progress,done,closed'],
        ]);

        $oldStatus = (string) $requestItem->status;
        $requestItem->update($data);
        $newStatus = (string) ($data['status'] ?? $oldStatus);
        if ($oldStatus !== $newStatus) {
            $unitLabel = (string) optional($requestItem->unit?->property)->name.'/'.(optional($requestItem->unit)->label ?? '—');
            $this->notifyTenantProgress(
                $requestItem,
                'Maintenance request #'.$requestItem->id.' update',
                'Your request at '.$unitLabel.' moved from '
                .str_replace('_', ' ', $oldStatus)
                .' to '
                .str_replace('_', ' ', $newStatus)
                .'.'
            );
        }

        return back()->with('success', 'Maintenance request updated.');
    }

    public function jobs(Request $request): View
    {
        $filters = $request->only(['q', 'status', 'vendor_id', 'from', 'to', 'sort', 'dir', 'per_page']);
        $jobQuery = $this->jobsQuery($filters);
        $statsSource = (clone $jobQuery)->get();
        $perPage = $this->listPerPage($filters);
        $jobs = $jobQuery->paginate($perPage)->withQueryString();

        $mtdCompletedCount = PmMaintenanceJob::query()
            ->whereNotNull('completed_at')
            ->whereYear('completed_at', now()->year)
            ->whereMonth('completed_at', now()->month)
            ->count();
        $mtdSpend = (float) PmMaintenanceJob::query()
            ->whereNotNull('completed_at')
            ->whereYear('completed_at', now()->year)
            ->whereMonth('completed_at', now()->month)
            ->sum('quote_amount');

        $stats = [
            ['label' => 'Jobs', 'value' => (string) $statsSource->count(), 'hint' => 'Filtered'],
            ['label' => 'Completed (MTD)', 'value' => (string) $mtdCompletedCount, 'hint' => ''],
            ['label' => 'Spend (MTD)', 'value' => PropertyMoney::kes($mtdSpend), 'hint' => 'Quoted'],
        ];

        $rows = $jobs->getCollection()->map(function (PmMaintenanceJob $j) {
            $approved = in_array($j->status, ['approved', 'in_progress', 'done'], true) ? 'Yes' : 'No';
            $schedule = $j->completed_at?->format('Y-m-d') ?? ($j->updated_at?->format('Y-m-d') ?? '—');

            $actionsBody =
                '<a href="'.route('property.maintenance.jobs.edit', $j).'" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">Edit</a>'.
                '<a href="'.route('property.maintenance.history').'" class="block px-3 py-2 text-xs text-indigo-700 hover:bg-indigo-50">History</a>'.
                '<form method="POST" action="'.route('property.maintenance.jobs.destroy', $j).'" class="block" data-swal-title="Delete job?" data-swal-confirm="Delete this job permanently?" data-swal-confirm-text="Yes, delete">'.csrf_field().method_field('DELETE').
                '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-rose-700 hover:bg-rose-50">Delete</button>'.
                '</form>';
            if (! in_array($j->status, ['done', 'cancelled'], true)) {
                $approveButton = '';
                if ($j->status === 'quoted') {
                    $approveButton =
                        '<form method="POST" action="'.route('property.maintenance.jobs.status', $j).'" class="block">'.csrf_field().
                        '<input type="hidden" name="status" value="approved" />'.
                        '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-indigo-700 hover:bg-indigo-50">Approve</button>'.
                        '</form>';
                }

                $actionsBody =
                    '<a href="'.route('property.maintenance.jobs.edit', $j).'" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">Edit</a>'.
                    $approveButton.
                    '<form method="POST" action="'.route('property.maintenance.jobs.status', $j).'" class="block">'.csrf_field().
                    '<input type="hidden" name="status" value="in_progress" />'.
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50">Start</button>'.
                    '</form>'.
                    '<form method="POST" action="'.route('property.maintenance.jobs.status', $j).'" class="block">'.csrf_field().
                    '<input type="hidden" name="status" value="done" />'.
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-emerald-700 hover:bg-emerald-50">Mark done</button>'.
                    '</form>'.
                    '<form method="POST" action="'.route('property.maintenance.jobs.status', $j).'" class="block" data-swal-title="Cancel job?" data-swal-confirm="Cancel this job?" data-swal-confirm-text="Yes, cancel">'.csrf_field().
                    '<input type="hidden" name="status" value="cancelled" />'.
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-rose-700 hover:bg-rose-50">Cancel</button>'.
                    '</form>'.
                    '<a href="'.route('property.maintenance.history').'" class="block px-3 py-2 text-xs text-indigo-700 hover:bg-indigo-50">History</a>'.
                    '<form method="POST" action="'.route('property.maintenance.jobs.destroy', $j).'" class="block" data-swal-title="Delete job?" data-swal-confirm="Delete this job permanently?" data-swal-confirm-text="Yes, delete">'.csrf_field().method_field('DELETE').
                    '<button type="submit" class="block w-full px-3 py-2 text-left text-xs text-rose-700 hover:bg-rose-50">Delete</button>'.
                    '</form>'.
                    '';
            }

            $actions = new HtmlString(
                '<div class="relative inline-block text-left">'.
                '<details>'.
                '<summary class="list-none cursor-pointer rounded border border-slate-300 px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50">Actions <span class="text-slate-400">▼</span></summary>'.
                '<div class="absolute right-0 z-30 mt-1 w-44 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-lg">'.
                $actionsBody.
                '</div>'.
                '</details>'.
                '</div>'
            );

            return [
                '#'.$j->id,
                $j->request->unit->property->name.'/'.$j->request->unit->label,
                $j->vendor?->name ?? '—',
                $j->quote_amount !== null ? number_format((float) $j->quote_amount, 2) : '—',
                $approved,
                $schedule,
                ucfirst(str_replace('_', ' ', $j->status)),
                $actions,
            ];
        })->all();

        return property_view('property.agent.maintenance.jobs', [
            'stats' => $stats,
            'columns' => ['Job #', 'Unit', 'Vendor', 'Quote', 'Approved', 'Schedule', 'Status', 'Actions'],
            'tableRows' => $rows,
            'requests' => PmMaintenanceRequest::query()->with('unit.property')->orderByDesc('id')->limit(100)->get(),
            'vendors' => PmVendor::query()->where('status', 'active')->orderBy('name')->get(),
            'filters' => [...$filters, 'per_page' => $perPage],
            'jobsPager' => $jobs,
        ]);
    }

    public function jobsExport(Request $request)
    {
        $filters = $request->only(['q', 'status', 'vendor_id', 'from', 'to', 'sort', 'dir']);
        $rows = $this->jobsQuery($filters)->get();

        return CsvExport::stream(
            'maintenance_jobs_'.now()->format('Ymd_His').'.csv',
            ['ID', 'Unit', 'Vendor', 'Quote', 'Status', 'Completed At', 'Notes'],
            function () use ($rows) {
                foreach ($rows as $j) {
                    yield [
                        $j->id,
                        $j->request->unit->property->name.'/'.$j->request->unit->label,
                        $j->vendor?->name,
                        $j->quote_amount,
                        $j->status,
                        optional($j->completed_at)->format('Y-m-d H:i:s'),
                        $j->notes,
                    ];
                }
            }
        );
    }

    public function storeJob(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'pm_maintenance_request_id' => ['required', 'exists:pm_maintenance_requests,id'],
            'pm_vendor_id' => ['nullable', 'exists:pm_vendors,id'],
            'quote_amount' => ['nullable', 'numeric', 'min:0'],
            'status' => ['required', 'in:quoted,approved,in_progress,done,cancelled'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        $completedAt = $data['status'] === 'done' ? now() : null;

        $job = PmMaintenanceJob::query()->create([
            ...$data,
            'completed_at' => $completedAt,
        ]);
        PropertyAccountingPostingService::postMaintenanceExpense($job, $request->user());

        return back()->with('success', 'Job saved.');
    }

    public function editJob(PmMaintenanceJob $job): View
    {
        $job->load(['request.unit.property', 'vendor']);

        return property_view('property.agent.maintenance.job_edit', [
            'job' => $job,
            'requests' => PmMaintenanceRequest::query()->with('unit.property')->orderByDesc('id')->limit(200)->get(),
            'vendors' => PmVendor::query()->where('status', 'active')->orderBy('name')->get(),
        ]);
    }

    public function updateJob(Request $request, PmMaintenanceJob $job): RedirectResponse
    {
        $data = $request->validate([
            'pm_maintenance_request_id' => ['required', 'exists:pm_maintenance_requests,id'],
            'pm_vendor_id' => ['nullable', 'exists:pm_vendors,id'],
            'quote_amount' => ['nullable', 'numeric', 'min:0'],
            'status' => ['required', 'in:quoted,approved,in_progress,done,cancelled'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        $status = $data['status'];
        $oldStatus = (string) $job->status;
        $job->update([
            ...$data,
            'completed_at' => $status === 'done' ? now() : null,
        ]);
        $job->loadMissing(['request.unit.property', 'vendor']);

        if ($status === 'done') {
            PropertyAccountingPostingService::postMaintenanceExpense($job, $request->user());
        }
        if ($oldStatus !== $status && $job->request) {
            $unitLabel = (string) optional($job->request->unit?->property)->name.'/'.(optional($job->request->unit)->label ?? '—');
            $vendorName = (string) ($job->vendor?->name ?? 'assigned vendor');
            $this->notifyTenantProgress(
                $job->request,
                'Maintenance job #'.$job->id.' update',
                'Work on '.$unitLabel.' moved from '
                .str_replace('_', ' ', $oldStatus)
                .' to '
                .str_replace('_', ' ', $status)
                .' with '.$vendorName.'.'
            );
        }

        return redirect()->route('property.maintenance.jobs')->with('success', 'Job updated.');
    }

    public function destroyJob(PmMaintenanceJob $job): RedirectResponse
    {
        $job->delete();

        return back()->with('success', 'Job deleted.');
    }

    public function updateJobStatus(Request $request, PmMaintenanceJob $job): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', 'in:quoted,approved,in_progress,done,cancelled'],
        ]);

        $status = $data['status'];
        $oldStatus = (string) $job->status;
        $job->update([
            'status' => $status,
            'completed_at' => $status === 'done' ? now() : null,
        ]);
        $job->loadMissing(['request.unit.property', 'vendor']);

        if ($status === 'done') {
            PropertyAccountingPostingService::postMaintenanceExpense($job, $request->user());
        }
        if ($oldStatus !== $status && $job->request) {
            $unitLabel = (string) optional($job->request->unit?->property)->name.'/'.(optional($job->request->unit)->label ?? '—');
            $vendorName = (string) ($job->vendor?->name ?? 'assigned vendor');
            $this->notifyTenantProgress(
                $job->request,
                'Maintenance job #'.$job->id.' update',
                'Work on '.$unitLabel.' moved from '
                .str_replace('_', ' ', $oldStatus)
                .' to '
                .str_replace('_', ' ', $status)
                .' with '.$vendorName.'.'
            );
        }

        return back()->with('success', 'Job status updated.');
    }

    public function history(): View
    {
        $jobs = PmMaintenanceJob::query()
            ->with(['request.unit.property', 'vendor'])
            ->where(function ($q) {
                $q->where('status', 'done')->orWhere('status', 'cancelled');
            })
            ->orderByDesc('completed_at')
            ->orderByDesc('id')
            ->limit(200)
            ->get();

        $stats = [
            ['label' => 'Closed jobs', 'value' => (string) $jobs->count(), 'hint' => 'Listed'],
            ['label' => 'Done', 'value' => (string) $jobs->where('status', 'done')->count(), 'hint' => ''],
            ['label' => 'Cancelled', 'value' => (string) $jobs->where('status', 'cancelled')->count(), 'hint' => ''],
        ];

        $rows = $jobs->map(fn (PmMaintenanceJob $j) => [
            $j->completed_at?->format('Y-m-d') ?? '—',
            '#'.$j->id,
            $j->request->unit->property->name.'/'.$j->request->unit->label,
            $j->vendor?->name ?? '—',
            $j->quote_amount !== null ? number_format((float) $j->quote_amount, 2) : '—',
            ucfirst(str_replace('_', ' ', $j->status)),
            Str::limit((string) $j->notes, 36),
        ])->all();

        return property_view('property.agent.maintenance.history', [
            'stats' => $stats,
            'columns' => ['Completed', 'Job #', 'Unit', 'Vendor', 'Quote', 'Status', 'Notes'],
            'tableRows' => $rows,
        ]);
    }

    public function costs(): View
    {
        $jobs = PmMaintenanceJob::query()
            ->with(['request.unit.property'])
            ->whereNotNull('quote_amount')
            ->orderByDesc('id')
            ->limit(500)
            ->get();

        $ytd = $jobs->filter(fn (PmMaintenanceJob $j) => $j->completed_at
            && (int) $j->completed_at->year === (int) now()->year);
        $ytdSum = (float) $ytd->sum('quote_amount');

        $byCategory = $jobs->groupBy(fn (PmMaintenanceJob $j) => $j->request->category ?: 'General');

        $rows = $byCategory->map(function ($group, $category) {
            /** @var Collection<int, PmMaintenanceJob> $group */
            $sum = (float) $group->sum(fn (PmMaintenanceJob $j) => (float) $j->quote_amount);
            $done = $group->where('status', 'done')->count();
            $avg = $group->count() > 0 ? $sum / $group->count() : 0.0;

            return [
                (string) $category,
                'All properties',
                now()->format('Y'),
                PropertyMoney::kes($sum),
                (string) $group->count(),
                'Avg '.PropertyMoney::kes($avg),
                $done.' completed',
            ];
        })->values()->all();

        $unitCount = PropertyUnit::query()->count();
        $costPerDoor = $unitCount > 0 ? $ytdSum / $unitCount : 0.0;
        $topCategory = '—';
        if ($byCategory->isNotEmpty()) {
            $topCategory = (string) $byCategory->sortByDesc(fn ($g) => $g->sum(fn (PmMaintenanceJob $j) => (float) $j->quote_amount))->keys()->first();
        }

        return property_view('property.agent.maintenance.costs', [
            'stats' => [
                ['label' => 'Spend (YTD)', 'value' => PropertyMoney::kes($ytdSum), 'hint' => 'Completed jobs, quoted'],
                ['label' => 'Cost / door (YTD)', 'value' => PropertyMoney::kes($costPerDoor), 'hint' => 'Avg across '.$unitCount.' units'],
                ['label' => 'Top cost driver', 'value' => (string) $topCategory, 'hint' => 'By request category'],
                ['label' => 'Jobs with quotes', 'value' => (string) $jobs->count(), 'hint' => 'Listed sample'],
            ],
            'columns' => ['Scope', 'Property / unit', 'Period', 'Spend', 'Tickets', 'vs budget', 'Notes'],
            'tableRows' => $rows,
        ]);
    }

    private function requestsQuery(array $filters): Builder
    {
        $q = PmMaintenanceRequest::query()->with(['unit.property', 'reportedBy']);

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $q->where(function (Builder $b) use ($search) {
                $b->where('category', 'like', '%'.$search.'%')
                    ->orWhere('description', 'like', '%'.$search.'%')
                    ->orWhereHas('unit', function (Builder $u) use ($search) {
                        $u->where('label', 'like', '%'.$search.'%')
                            ->orWhereHas('property', fn (Builder $p) => $p->where('name', 'like', '%'.$search.'%'));
                    });
            });
        }

        foreach (['status', 'urgency'] as $f) {
            $v = trim((string) ($filters[$f] ?? ''));
            if ($v !== '') {
                $q->where($f, $v);
            }
        }

        $unitId = (int) ($filters['unit_id'] ?? 0);
        if ($unitId > 0) {
            $q->where('property_unit_id', $unitId);
        }

        $from = trim((string) ($filters['from'] ?? ''));
        if ($from !== '') {
            $q->whereDate('created_at', '>=', $from);
        }
        $to = trim((string) ($filters['to'] ?? ''));
        if ($to !== '') {
            $q->whereDate('created_at', '<=', $to);
        }

        $sort = (string) ($filters['sort'] ?? 'created_at');
        $dir = strtolower((string) ($filters['dir'] ?? 'desc')) === 'asc' ? 'asc' : 'desc';
        $allowedSort = ['id', 'created_at', 'status', 'urgency'];
        if (! in_array($sort, $allowedSort, true)) {
            $sort = 'created_at';
        }

        return $q->orderBy($sort, $dir)->orderByDesc('id');
    }

    private function jobsQuery(array $filters): Builder
    {
        $q = PmMaintenanceJob::query()->with(['request.unit.property', 'vendor']);

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $q->where(function (Builder $b) use ($search) {
                $b->where('notes', 'like', '%'.$search.'%')
                    ->orWhereHas('vendor', fn (Builder $v) => $v->where('name', 'like', '%'.$search.'%'))
                    ->orWhereHas('request', function (Builder $r) use ($search) {
                        $r->where('category', 'like', '%'.$search.'%')
                            ->orWhere('description', 'like', '%'.$search.'%');
                    });
            });
        }

        $status = trim((string) ($filters['status'] ?? ''));
        if ($status !== '') {
            $q->where('status', $status);
        }

        $vendorId = (int) ($filters['vendor_id'] ?? 0);
        if ($vendorId > 0) {
            $q->where('pm_vendor_id', $vendorId);
        }

        $from = trim((string) ($filters['from'] ?? ''));
        if ($from !== '') {
            $q->whereDate('created_at', '>=', $from);
        }
        $to = trim((string) ($filters['to'] ?? ''));
        if ($to !== '') {
            $q->whereDate('created_at', '<=', $to);
        }

        $sort = (string) ($filters['sort'] ?? 'created_at');
        $dir = strtolower((string) ($filters['dir'] ?? 'desc')) === 'asc' ? 'asc' : 'desc';
        $allowedSort = ['id', 'created_at', 'status', 'completed_at'];
        if (! in_array($sort, $allowedSort, true)) {
            $sort = 'created_at';
        }

        return $q->orderBy($sort, $dir)->orderByDesc('id');
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    private function listPerPage(array $filters): int
    {
        $value = (int) ($filters['per_page'] ?? 20);

        return in_array($value, [10, 20, 50, 100], true) ? $value : 20;
    }

    public function frequency(): View
    {
        $requests = PmMaintenanceRequest::query()
            ->where('created_at', '>=', now()->subMonths(12))
            ->orderBy('created_at')
            ->get();

        $byMonth = $requests->groupBy(fn (PmMaintenanceRequest $r) => $r->created_at->format('Y-m'));
        $rows = $byMonth->map(function ($group, $ym) {
            $byCat = $group->groupBy(fn (PmMaintenanceRequest $r) => $r->category ?: 'General');
            $repeatUnits = $group
                ->groupBy('property_unit_id')
                ->filter(fn ($g) => $g->count() > 1)
                ->count();
            $note = $group->where('urgency', 'emergency')->count() > 0 ? 'Emergency activity' : 'Routine';

            return [
                (string) $ym,
                (string) $group->count(),
                (string) $byCat->count(),
                (string) $group->where('urgency', 'emergency')->count(),
                (string) $repeatUnits,
                $note,
            ];
        })->sortKeysDesc()->values()->all();

        $unitCount = PropertyUnit::query()->count();
        $monthsWithData = $byMonth->count();
        $emergencyTotal = $requests->where('urgency', 'emergency')->count();

        return property_view('property.agent.maintenance.frequency', [
            'stats' => [
                ['label' => 'Requests (12 mo)', 'value' => (string) $requests->count(), 'hint' => ''],
                ['label' => 'Months with data', 'value' => (string) $monthsWithData, 'hint' => ''],
                ['label' => 'Emergency (12 mo)', 'value' => (string) $emergencyTotal, 'hint' => ''],
                ['label' => 'Units in portfolio', 'value' => (string) $unitCount, 'hint' => ''],
            ],
            'columns' => ['Month', 'Tickets', 'Categories touched', 'Emergency', 'Repeat units', 'Notes'],
            'tableRows' => $rows,
        ]);
    }

    private function resolveTenantIdForMaintenanceUnit(int $propertyUnitId): ?int
    {
        $lease = PmLease::query()
            ->where('status', PmLease::STATUS_ACTIVE)
            ->whereHas('units', fn ($q) => $q->where('property_units.id', $propertyUnitId))
            ->orderByDesc('start_date')
            ->first();

        return $lease ? (int) $lease->pm_tenant_id : null;
    }
}
