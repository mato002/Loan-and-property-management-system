<?php

namespace App\Http\Controllers\Property\Agent;

use App\Http\Controllers\Controller;
use App\Mail\LandlordPortalCredentialsMail;
use App\Models\PmLease;
use App\Models\Property;
use App\Models\PropertyUnit;
use App\Models\User;
use App\Services\Property\PropertyMoney;
use Illuminate\Support\HtmlString;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Throwable;

class PropertyPortfolioController extends Controller
{
    private function generateUniquePropertyCode(string $name): string
    {
        $base = strtoupper(Str::of($name)->slug('')->substr(0, 6)->toString());
        $base = $base !== '' ? $base : 'PROP';

        // Try a few times; code is unique in DB, so we must avoid collisions.
        for ($i = 0; $i < 25; $i++) {
            $suffix = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
            $candidate = $base.'-'.$suffix; // e.g. "GREENH-0421"
            if (!Property::query()->where('code', $candidate)->exists()) {
                return $candidate;
            }
        }

        // Extremely unlikely fallback.
        return 'PROP-'.strtoupper(Str::random(8));
    }

    public function propertyList(): View
    {
        $portfolio = Property::query()
            ->with(['landlords' => fn ($q) => $q->orderBy('name')])
            ->withCount('units')
            ->orderBy('name')
            ->get();

        $stats = [
            ['label' => 'Properties', 'value' => (string) $portfolio->count(), 'hint' => 'In portfolio'],
            ['label' => 'Total units', 'value' => (string) PropertyUnit::query()->count(), 'hint' => 'Across all'],
            ['label' => 'Occupied', 'value' => (string) PropertyUnit::query()->where('status', PropertyUnit::STATUS_OCCUPIED)->count(), 'hint' => 'Units'],
            ['label' => 'Vacant', 'value' => (string) PropertyUnit::query()->where('status', PropertyUnit::STATUS_VACANT)->count(), 'hint' => 'Units'],
        ];

        $rows = $portfolio->map(function (Property $p) {
            $landlordCell = $p->landlords->isEmpty()
                ? '—'
                : $p->landlords->pluck('name')->join(', ');
            $action = new HtmlString(
                '<a href="'.route('property.properties.edit', $p).'" class="text-indigo-600 hover:text-indigo-700 font-medium">Edit</a>'
            );

            return [
                $p->name,
                $p->code ?? '—',
                $p->address_line ?? '—',
                (string) $p->units_count,
                $p->city ?? '—',
                $landlordCell,
                'Active',
                $action,
            ];
        })->all();

        $landlordLinks = DB::table('property_landlord')
            ->join('properties', 'properties.id', '=', 'property_landlord.property_id')
            ->join('users', 'users.id', '=', 'property_landlord.user_id')
            ->select([
                'property_landlord.id',
                'properties.id as property_id',
                'properties.name as property_name',
                'users.id as user_id',
                'users.name as user_name',
                'users.email as user_email',
                'property_landlord.ownership_percent',
            ])
            ->orderBy('properties.name')
            ->orderBy('users.name')
            ->get();

        return view('property.agent.properties.list', [
            'stats' => $stats,
            'columns' => ['Name', 'Code', 'Address', 'Units', 'City', 'Landlord(s)', 'Status', 'Actions'],
            'tableRows' => $rows,
            'landlordUsers' => User::query()->where('property_portal_role', 'landlord')->orderBy('name')->get(),
            'properties' => $portfolio,
            'landlordLinks' => $landlordLinks,
        ]);
    }

    public function editProperty(Property $property): View
    {
        $property->load(['landlords' => fn ($q) => $q->orderBy('name')]);

        return view('property.agent.properties.edit', [
            'property' => $property,
            'landlordUsers' => User::query()->where('property_portal_role', 'landlord')->orderBy('name')->get(),
        ]);
    }

    public function updateProperty(Request $request, Property $property): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'code' => ['nullable', 'string', 'max:64', 'unique:properties,code,'.$property->id],
            'address_line' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:128'],
        ]);

        $property->update($data);

        return back()->with('success', 'Property updated.');
    }

    public function detachLandlord(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'user_id' => ['required', 'exists:users,id'],
        ]);

        $property = Property::query()->findOrFail($data['property_id']);
        $property->landlords()->detach($data['user_id']);

        return back()->with('success', __('Landlord unlinked from property.'));
    }

    public function updateLandlordOwnership(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'user_id' => ['required', 'exists:users,id'],
            'ownership_percent' => ['required', 'numeric', 'min:0', 'max:100'],
        ]);

        $property = Property::query()->findOrFail($data['property_id']);
        if (! $property->landlords()->whereKey($data['user_id'])->exists()) {
            return back()->withErrors(['user_id' => __('That landlord is not linked to this property.')]);
        }

        $newPct = (float) $data['ownership_percent'];
        $others = (float) $property->landlords()
            ->where('users.id', '!=', $data['user_id'])
            ->sum('property_landlord.ownership_percent');

        if ($others + $newPct > 100.0001) {
            return back()->withErrors(['ownership_percent' => __('Total ownership for this property cannot exceed 100%.')]);
        }

        $property->landlords()->updateExistingPivot($data['user_id'], [
            'ownership_percent' => $newPct,
        ]);

        return back()->with('success', __('Ownership % updated.'));
    }

    public function propertyPerformance(): View
    {
        $units = PropertyUnit::query()
            ->with([
                'property',
                'leases' => fn ($q) => $q->where('status', PmLease::STATUS_ACTIVE),
            ])
            ->orderBy('property_id')
            ->orderBy('label')
            ->get();

        $lossToLease = 0.0;
        $rows = $units->map(function (PropertyUnit $u) use (&$lossToLease) {
            $lease = $u->leases->first();
            $asking = (float) $u->rent_amount;
            $effective = $lease ? (float) $lease->monthly_rent : null;
            $delta = $effective !== null ? $effective - $asking : null;
            if ($delta !== null && $delta < 0) {
                $lossToLease += abs($delta);
            }

            $vacancyDays = ($u->status === PropertyUnit::STATUS_VACANT && $u->vacant_since)
                ? (int) $u->vacant_since->diffInDays(now())
                : 0;

            $collected = '—';
            $target = PropertyMoney::kes($asking);
            $variance = $delta === null ? '—' : PropertyMoney::kes($delta);
            $trend = $u->status === PropertyUnit::STATUS_VACANT ? 'Vacant' : ($delta !== null && $delta < 0 ? 'Below ask' : 'At/above ask');

            return [
                $u->label,
                $u->property->name,
                (string) $vacancyDays,
                $collected,
                $target,
                $variance,
                $trend,
            ];
        })->all();

        $worst = $units->filter(fn (PropertyUnit $u) => $u->status === PropertyUnit::STATUS_VACANT)->count();

        return view('property.agent.properties.performance', [
            'stats' => [
                ['label' => 'Loss to lease (est.)', 'value' => PropertyMoney::kes($lossToLease), 'hint' => 'Active leases below asking'],
                ['label' => 'Vacant units', 'value' => (string) $worst, 'hint' => 'Current'],
                ['label' => 'Total units', 'value' => (string) $units->count(), 'hint' => ''],
                ['label' => 'With active lease', 'value' => (string) $units->filter(fn (PropertyUnit $u) => $u->leases->isNotEmpty())->count(), 'hint' => ''],
            ],
            'columns' => ['Unit', 'Property', 'Days vacant (current)', 'Collected', 'Target', 'Variance', 'Trend'],
            'tableRows' => $rows,
        ]);
    }

    public function landlordsIndex(): View
    {
        $landlords = User::query()
            ->where('property_portal_role', 'landlord')
            ->with(['landlordProperties' => fn ($q) => $q->orderBy('name')])
            ->orderBy('name')
            ->get();

        $linked = $landlords->filter(fn (User $u) => $u->landlordProperties->isNotEmpty());

        $stats = [
            ['label' => 'Landlord accounts', 'value' => (string) $landlords->count(), 'hint' => 'Landlord portal role'],
            ['label' => 'Linked to properties', 'value' => (string) $linked->count(), 'hint' => 'At least one building'],
            ['label' => 'Not linked yet', 'value' => (string) ($landlords->count() - $linked->count()), 'hint' => 'Use link form on property list'],
        ];

        return view('property.agent.landlords.index', [
            'stats' => $stats,
            'landlords' => $landlords,
            'properties' => Property::query()->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function onboardLandlord(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'max:255'],
            'property_id' => ['nullable', 'exists:properties,id'],
            'ownership_percent' => ['nullable', 'numeric', 'min:0', 'max:100'],
        ]);

        $plainPassword = $data['password'];
        $landlord = User::query()->create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $plainPassword,
            'property_portal_role' => 'landlord',
        ]);

        if (! empty($data['property_id'])) {
            $property = Property::query()->findOrFail((int) $data['property_id']);
            $pct = (float) ($data['ownership_percent'] ?? 100);

            $currentSum = (float) $property->landlords()->sum('property_landlord.ownership_percent');
            if ($currentSum + $pct > 100.0001) {
                $landlord->delete();

                return back()->withErrors([
                    'ownership_percent' => __('Total ownership for this property would exceed 100%.'),
                ])->withInput();
            }

            $property->landlords()->attach($landlord->id, ['ownership_percent' => $pct]);
        }

        $mailWarning = null;
        try {
            Mail::to($landlord->email)->send(new LandlordPortalCredentialsMail(
                landlordName: $landlord->name,
                email: $landlord->email,
                plainPassword: $plainPassword,
                loginUrl: route('login'),
                landlordHomeUrl: route('property.landlord.portfolio'),
            ));
        } catch (Throwable) {
            $mailWarning = ' Landlord account created, but credential email was not sent (check mail settings).';
        }

        $message = $mailWarning === null
            ? 'Landlord onboarded successfully. Credentials email sent.'
            : 'Landlord onboarded successfully.'.$mailWarning;

        return back()->with('success', $message);
    }

    public function storeProperty(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'code' => ['nullable', 'string', 'max:64', 'unique:properties,code'],
            'address_line' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:128'],
        ]);

        if (!isset($data['code']) || trim((string) $data['code']) === '') {
            $data['code'] = $this->generateUniquePropertyCode($data['name']);
        }

        $property = Property::query()->create($data);

        return back()
            ->with('success', 'Property saved.')
            ->with('next_steps', [
                'title' => 'Property saved',
                'message' => 'Next, add units (doors), then link the landlord user, then publish vacant units under Listings.',
                'actions' => [
                    [
                        'label' => 'Add units',
                        'href' => route('property.properties.units', ['property_id' => $property->id], absolute: false),
                        'kind' => 'primary',
                        'icon' => 'fa-solid fa-building',
                        'turbo_frame' => 'property-main',
                    ],
                    [
                        'label' => 'Link landlord user',
                        'href' => route('property.properties.list', ['property_id' => $property->id], absolute: false).'#link-landlord-form',
                        'kind' => 'secondary',
                        'icon' => 'fa-solid fa-user-tie',
                        'turbo_frame' => 'property-main',
                    ],
                    [
                        'label' => 'Go to Listings',
                        'href' => route('property.listings.index', absolute: false),
                        'kind' => 'ghost',
                        'icon' => 'fa-solid fa-bullhorn',
                        'turbo_frame' => 'property-main',
                    ],
                ],
            ]);
    }

    public function unitList(): View
    {
        $units = PropertyUnit::query()->with('property')->orderBy('property_id')->orderBy('label')->get();

        $stats = [
            ['label' => 'Units', 'value' => (string) $units->count(), 'hint' => 'Total'],
            ['label' => 'Occupied', 'value' => (string) $units->where('status', PropertyUnit::STATUS_OCCUPIED)->count(), 'hint' => ''],
            ['label' => 'Vacant', 'value' => (string) $units->where('status', PropertyUnit::STATUS_VACANT)->count(), 'hint' => ''],
            ['label' => 'Listed rent (avg)', 'value' => $units->count() ? PropertyMoney::kes($units->avg('rent_amount')) : PropertyMoney::kes(0), 'hint' => 'Asking'],
        ];

        $rows = $units->map(function (PropertyUnit $u) {
            $action = new HtmlString(
                '<a href="'.route('property.properties.units').'" class="text-indigo-600 hover:text-indigo-700 font-medium">Manage unit</a>'
            );

            if ($u->status === PropertyUnit::STATUS_VACANT) {
                $action = new HtmlString(
                    '<a href="'.route('property.listings.vacant.public.edit', $u).'" class="text-indigo-600 hover:text-indigo-700 font-medium">Edit listing</a>'
                );
            }

            return [
                $u->label,
                $u->property->name,
                $u->unitTypeLabel(),
                $u->bedroomsLabel(),
                PropertyMoney::kes((float) $u->rent_amount),
                ucfirst($u->status),
                '—',
                $u->vacant_since?->format('Y-m-d') ?? '—',
                $action,
            ];
        })->all();

        return view('property.agent.properties.units', [
            'stats' => $stats,
            'columns' => ['Unit', 'Property', 'Type', 'Beds', 'Rent', 'Status', 'Tenant', 'Vacant since', 'Actions'],
            'tableRows' => $rows,
            'properties' => Property::query()->orderBy('name')->get(),
            'unitTypes' => PropertyUnit::typeOptions(),
        ]);
    }

    public function storeUnit(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'label' => ['required', 'string', 'max:64'],
            'unit_type' => ['required', 'string', 'in:'.implode(',', array_keys(PropertyUnit::typeOptions()))],
            // Bedrooms is conditional: some unit types have no separate bedroom and the UI disables the field.
            'bedrooms' => ['nullable', 'integer', 'min:0', 'max:20'],
            'rent_amount' => ['required', 'numeric', 'min:0'],
            'status' => ['required', 'in:vacant,occupied,notice'],
            'public_listing_description' => ['nullable', 'string', 'max:20000'],
        ]);

        $desc = isset($data['public_listing_description']) && trim((string) $data['public_listing_description']) !== ''
            ? $data['public_listing_description']
            : null;
        $noBedroomTypes = [PropertyUnit::TYPE_SINGLE_ROOM, PropertyUnit::TYPE_BEDSITTER, PropertyUnit::TYPE_STUDIO];
        $requiresNoBedroom = in_array($data['unit_type'], $noBedroomTypes, true);
        if ($requiresNoBedroom) {
            $data['bedrooms'] = 0;
        } elseif (!isset($data['bedrooms'])) {
            return back()
                ->withErrors(['bedrooms' => __('The bedrooms field is required.')])
                ->withInput();
        }

        $unit = PropertyUnit::query()->create([
            ...$data,
            'rent_amount' => $data['rent_amount'],
            'public_listing_description' => $desc,
            'vacant_since' => $data['status'] === PropertyUnit::STATUS_VACANT ? now()->toDateString() : null,
        ]);

        $actions = [
            [
                'label' => 'Add another unit',
                'href' => route('property.properties.units', ['property_id' => $unit->property_id], absolute: false),
                'kind' => 'primary',
                'icon' => 'fa-solid fa-plus',
                'turbo_frame' => 'property-main',
            ],
            [
                'label' => 'Link landlord user',
                'href' => route('property.properties.list', ['property_id' => $unit->property_id], absolute: false).'#link-landlord-form',
                'kind' => 'secondary',
                'icon' => 'fa-solid fa-user-tie',
                'turbo_frame' => 'property-main',
            ],
            [
                'label' => 'Go to Listings',
                'href' => route('property.listings.index', absolute: false),
                'kind' => 'ghost',
                'icon' => 'fa-solid fa-bullhorn',
                'turbo_frame' => 'property-main',
            ],
        ];

        if ($unit->status === PropertyUnit::STATUS_VACANT) {
            array_unshift($actions, [
                'label' => 'Edit listing (vacant unit)',
                'href' => route('property.listings.vacant.public.edit', $unit, absolute: false),
                'kind' => 'primary',
                'icon' => 'fa-solid fa-pen-to-square',
                'turbo_frame' => 'property-main',
            ]);
        }

        return back()
            ->with('success', 'Unit saved.')
            ->with('next_steps', [
                'title' => 'Unit saved',
                'message' => $unit->status === PropertyUnit::STATUS_VACANT
                    ? 'This unit is vacant. You can now add photos and publish it under Listings.'
                    : 'Next, add more units, link the landlord, or manage listings for vacant units.',
                'actions' => $actions,
            ]);
    }

    public function attachLandlord(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'user_id' => ['required', 'exists:users,id'],
            'ownership_percent' => ['nullable', 'numeric', 'min:0', 'max:100'],
        ]);

        $property = Property::query()->findOrFail($data['property_id']);
        $pct = (float) ($data['ownership_percent'] ?? 100);

        $currentSum = (float) $property->landlords()->sum('property_landlord.ownership_percent');
        if ($currentSum + $pct > 100.0001) {
            return back()->withErrors(['ownership_percent' => __('Total ownership for this property would exceed 100%.')]);
        }

        $property->landlords()->syncWithoutDetaching([
            $data['user_id'] => ['ownership_percent' => $pct],
        ]);

        return back()
            ->with('success', 'Landlord linked to property.')
            ->with('next_steps', [
                'title' => 'Landlord linked',
                'message' => 'Next, add units for this property, then publish vacant units under Listings.',
                'actions' => [
                    [
                        'label' => 'Add units',
                        'href' => route('property.properties.units', ['property_id' => $property->id], absolute: false),
                        'kind' => 'primary',
                        'icon' => 'fa-solid fa-building',
                        'turbo_frame' => 'property-main',
                    ],
                    [
                        'label' => 'View properties list',
                        'href' => route('property.properties.list', ['property_id' => $property->id], absolute: false),
                        'kind' => 'secondary',
                        'icon' => 'fa-solid fa-list',
                        'turbo_frame' => 'property-main',
                    ],
                    [
                        'label' => 'Go to Listings',
                        'href' => route('property.listings.index', absolute: false),
                        'kind' => 'ghost',
                        'icon' => 'fa-solid fa-bullhorn',
                        'turbo_frame' => 'property-main',
                    ],
                ],
            ]);
    }

    public function occupancy(): View
    {
        $units = PropertyUnit::query()
            ->with([
                'property',
                'leases' => fn ($q) => $q->where('status', PmLease::STATUS_ACTIVE)->with('pmTenant'),
            ])
            ->orderBy('property_id')
            ->orderBy('label')
            ->get();

        $total = $units->count();
        $occ = $units->where('status', PropertyUnit::STATUS_OCCUPIED)->count();
        $vac = $units->where('status', PropertyUnit::STATUS_VACANT)->count();
        $notice = $units->where('status', PropertyUnit::STATUS_NOTICE)->count();
        $rate = $total > 0 ? round(100 * $occ / $total, 1) : null;

        $stats = [
            ['label' => 'Occupancy rate', 'value' => $rate !== null ? $rate.'%' : '—', 'hint' => 'Occupied / all units'],
            ['label' => 'Occupied', 'value' => (string) $occ, 'hint' => 'Units'],
            ['label' => 'Vacant', 'value' => (string) $vac, 'hint' => 'Units'],
            ['label' => 'Notice', 'value' => (string) $notice, 'hint' => 'Move-out pipeline'],
        ];

        $rows = $units->map(function (PropertyUnit $u) {
            $lease = $u->leases->first();
            $tenant = $lease?->pmTenant;

            return [
                $u->label,
                $u->property->name,
                ucfirst($u->status),
                $tenant?->name ?? '—',
                PropertyMoney::kes((float) $u->rent_amount),
                $u->vacant_since?->format('Y-m-d') ?? '—',
            ];
        })->all();

        return view('property.agent.properties.occupancy', [
            'stats' => $stats,
            'columns' => ['Unit', 'Property', 'Status', 'Active tenant', 'List rent', 'Vacant since'],
            'tableRows' => $rows,
        ]);
    }
}
